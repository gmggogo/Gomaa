function getCompanyToken(){
  const own = String(localStorage.getItem("companyToken") || "").trim();
  if(own) return own;
  if(String(localStorage.getItem("role") || "").toLowerCase() === "company"){
    return String(localStorage.getItem("token") || "").trim();
  }
  return "";
}
function getCompanyRole(){
  const own = String(localStorage.getItem("companyRole") || "").trim();
  if(own) return own;
  const legacy = String(localStorage.getItem("role") || "").trim();
  return legacy.toLowerCase() === "company" ? legacy : "";
}
function getCompanyName(){
  const own = String(localStorage.getItem("companyName") || "").trim();
  if(own) return own;
  if(String(localStorage.getItem("role") || "").toLowerCase() === "company"){
    return String(localStorage.getItem("name") || "").trim();
  }
  return "";
}
function getCompanyTenantSlug(){
  return String(
    localStorage.getItem("companyTenantSlug") ||
    sessionStorage.getItem("companyTenantSlug") ||
    ""
  ).trim().toLowerCase();
}
function companyLoginUrl(){
  const slug = getCompanyTenantSlug();
  return slug
    ? `/companies/company-login.html?tenant=${encodeURIComponent(slug)}`
    : "/companies/company-login.html";
}
function companyStorageKey(baseKey){
  const scope =
    getCompanyTenantSlug() ||
    String(localStorage.getItem("companyTenantId") || "").trim() ||
    "company";
  return `${baseKey}:${scope}`;
}

/* =========================================
FILE: company-add-stop.js
COMPANY ADD STOP
Final Route Editor
Add Stops + Edit Existing Stops + Edit Dropoff
Local Confirm per row
Final Submit sends request to server
========================================= */

(function(){

/* ================= SECURITY ================= */

const token = getCompanyToken();
const role = getCompanyRole();
const companyName = getCompanyName();

if(!token || role !== "company"){
  window.location.href = companyLoginUrl();
  return;
}

/* ================= CONFIG ================= */

const params = new URLSearchParams(window.location.search);
const tripId = params.get("tripId") || "";

const MAX_STOPS = 5;
const REVIEW_URL = "/companies/review.html";

const API_TRIP_BY_ID = id =>
  `/api/trips/${encodeURIComponent(id)}`;

const API_COMPANY_TRIPS = companyName
  ? `/api/trips/company/${encodeURIComponent(companyName)}`
  : "/api/trips/company";

const API_ADD_STOP_CONFIRM = id =>
  `/api/company/add-stop/${encodeURIComponent(id)}/confirm`;

const API_ADD_STOP_CONTEXT = id =>
  `/api/company/add-stop/${encodeURIComponent(id)}/request?context=1`;

const DRIVER_LOCATION_ENDPOINTS = id => [
  "/api/admin/live-drivers"
];

/* ================= STATE ================= */

let currentTrip = null;

let SYSTEM_REGION = "";
let SYSTEM_COUNTRY = "";
let SYSTEM_TIMEZONE = "America/Phoenix";

let googleLoadPromise = null;
let uid = 0;

/*
  newStopDrafts:
  {
    id,
    insertAfterIndex,
    value
  }

  confirmedNewStops:
  {
    id,
    address,
    insertAfterIndex,
    rowIndex
  }

  insertAfterIndex:
  0 = after pickup
  1 = after existing stop 1
  2 = after existing stop 2
*/

let newStopDrafts = [];
let confirmedNewStops = [];

let editingExistingIndex = null;
let existingEditDrafts = {};
let confirmedExistingEdits = {};
let removedExistingStopIndexes = new Set();

let editingDropoff = false;
let dropoffDraft = "";
let confirmedDropoff = null;

/* ================= DOM ================= */

const loadingBox = document.getElementById("loadingBox");
const form = document.getElementById("addStopForm");
const alertBox = document.getElementById("alertBox");

const pageStatusBadge = document.getElementById("pageStatusBadge");

const tripNumberInput = document.getElementById("tripNumber");
const clientNameInput = document.getElementById("clientName");
const pickupAddressInput = document.getElementById("pickupAddress");
const dropoffAddressInput = document.getElementById("dropoffAddress");

const stopsContainer = document.getElementById("stopsContainer");
const addStopBtn = document.getElementById("addStopBtn");

const backBtn = document.getElementById("backBtn");
const confirmAddStopBtn = document.getElementById("confirmAddStopBtn");

/* ================= STYLE ================= */

(function injectStyle(){

  const old = document.getElementById("company-add-stop-dynamic-style");
  if(old) old.remove();

  const style = document.createElement("style");
  style.id = "company-add-stop-dynamic-style";

  style.innerHTML = `
    .old-add-stop-hidden{
      display:none!important;
    }

    .route-editor{
      margin:20px 0;
      background:#fff;
      border:1px solid #dbeafe;
      border-radius:18px;
      overflow:hidden;
      box-shadow:0 12px 28px rgba(15,23,42,.10);
    }

    .route-editor-head{
      background:linear-gradient(135deg,#0f172a,#1d4ed8);
      color:#fff;
      padding:16px;
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:10px;
      flex-wrap:wrap;
      font-weight:900;
    }

    .route-editor-title{
      font-size:18px;
    }

    .route-editor-badge{
      background:#fff;
      color:#1d4ed8;
      padding:6px 12px;
      border-radius:999px;
      font-size:12px;
      font-weight:900;
    }

    .route-editor-body{
      padding:16px;
      display:grid;
      gap:0;
      background:#fff;
    }

    .route-node{
      display:grid;
      grid-template-columns:52px 1fr;
      gap:12px;
      align-items:stretch;
    }

    .route-dot-wrap{
      display:flex;
      flex-direction:column;
      align-items:center;
    }

    .route-dot{
      width:38px;
      height:38px;
      border-radius:50%;
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
      font-weight:900;
      box-shadow:0 8px 18px rgba(15,23,42,.18);
      z-index:2;
    }

    .route-dot.pickup{
      background:#16a34a;
    }

    .route-dot.stop{
      background:#7c3aed;
    }

    .route-dot.dropoff{
      background:#dc2626;
    }

    .route-line{
      width:4px;
      flex:1;
      background:#cbd5e1;
      margin:4px 0;
      border-radius:999px;
      min-height:20px;
    }

    .route-card{
      background:#fff;
      border:1px solid #e2e8f0;
      border-radius:12px;
      margin-bottom:8px;
      overflow:hidden;
      box-shadow:0 3px 10px rgba(15,23,42,.05);
    }

    .route-card-head{
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:10px;
      padding:14px 14px 5px;
      background:#fff;
      border-bottom:none;
      font-weight:900;
      color:#0f172a;
      font-size:16px;
    }

    .route-card-head-left{
      display:flex;
      align-items:center;
      gap:8px;
      flex-wrap:wrap;
    }

    .route-card-head span.route-type{
      padding:4px 8px;
      border-radius:999px;
      font-size:11px;
      color:#fff;
      font-weight:900;
    }

    .route-card-head span.pickup{
      background:#16a34a;
    }

    .route-card-head span.stop{
      background:#7c3aed;
    }

    .route-card-head span.dropoff{
      background:#dc2626;
    }

    .route-card-head span.edited{
      background:#f59e0b;
      color:#111827;
      padding:4px 8px;
      border-radius:999px;
      font-size:11px;
      font-weight:900;
    }

    .route-address{
      padding:5px 14px 15px;
      font-size:14px;
      font-weight:700;
      line-height:1.45;
      color:#111827;
      word-break:break-word;
    }

    .route-actions{
      display:flex;
      align-items:center;
      gap:8px;
      flex-shrink:0;
    }

    .route-action-btn{
      border:none;
      background:#0f172a;
      color:#fff;
      padding:8px 11px;
      border-radius:10px;
      font-size:12px;
      font-weight:900;
      cursor:pointer;
    }

    .route-action-btn.edit{
      background:#2563eb;
    }

    .route-action-btn.cancel{
      background:#64748b;
    }

    .route-action-btn.delete{
      background:#dc2626;
    }

    .route-action-btn.confirm{
      background:#16a34a;
    }

    .edit-box{
      padding:12px;
      display:grid;
      gap:10px;
      background:#f8fafc;
    }

    .edit-input-row{
      display:grid;
      grid-template-columns:1fr auto auto;
      gap:8px;
      align-items:center;
    }

    .edit-input{
      width:100%;
      padding:12px;
      border:1px solid #cbd5e1;
      border-radius:12px;
      font-size:13px;
      font-weight:800;
      outline:none;
      background:#fff;
      color:#111827;
      box-sizing:border-box;
    }

    .edit-input:focus{
      border:2px solid #2563eb;
      box-shadow:0 0 0 3px rgba(37,99,235,.12);
    }

    .insert-zone{
      display:grid;
      grid-template-columns:52px 1fr;
      gap:12px;
      align-items:stretch;
    }

    .insert-line-wrap{
      display:flex;
      flex-direction:column;
      align-items:center;
    }

    .insert-line{
      width:4px;
      flex:1;
      background:#cbd5e1;
      border-radius:999px;
      min-height:28px;
    }

    .insert-content{
      padding:2px 0 14px;
    }

    .add-here-btn{
      width:auto;
      min-width:190px;
      margin:4px auto;
      border:2px solid #2563eb;
      background:#fff;
      color:#1d4ed8;
      padding:9px 18px;
      border-radius:10px;
      font-size:13px;
      font-weight:900;
      cursor:pointer;
      display:flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      box-shadow:none;
    }

    .add-here-btn span{
      color:#1d4ed8;
      font-size:19px;
      line-height:1;
      font-weight:900;
    }
    .slot-area{
      margin-top:10px;
      display:grid;
      gap:8px;
    }

    .draft-stop-row{
      display:grid;
      grid-template-columns:1fr auto auto;
      gap:8px;
      align-items:center;
      background:#f8fafc;
      border:1px solid #bfdbfe;
      border-radius:14px;
      padding:8px;
    }

    .draft-stop-input{
      width:100%;
      padding:12px;
      border:1px solid #cbd5e1;
      border-radius:12px;
      font-size:13px;
      font-weight:800;
      outline:none;
      background:#fff;
      color:#111827;
      box-sizing:border-box;
    }

    .draft-stop-input:focus{
      border:2px solid #2563eb;
      box-shadow:0 0 0 3px rgba(37,99,235,.12);
    }

    .draft-confirm-btn{
      border:none;
      background:#16a34a;
      color:#fff;
      padding:12px 14px;
      border-radius:12px;
      font-weight:900;
      cursor:pointer;
      white-space:nowrap;
    }

    .draft-remove-btn{
      min-width:72px;
      height:40px;
      border:none;
      border-radius:12px;
      background:#fee2e2;
      color:#dc2626;
      font-size:12px;
      font-weight:900;
      cursor:pointer;
    }

    .confirmed-stop-chip{
      display:grid;
      grid-template-columns:1fr auto;
      gap:8px;
      align-items:center;
      background:#ecfdf5;
      border:1px solid #bbf7d0;
      border-radius:14px;
      padding:9px;
    }

    .confirmed-stop-text{
      font-size:12px;
      font-weight:900;
      color:#14532d;
      line-height:1.35;
      word-break:break-word;
    }

    .confirmed-stop-remove{
      min-width:72px;
      height:40px;
      border:none;
      border-radius:12px;
      background:#fee2e2;
      color:#dc2626;
      font-size:12px;
      font-weight:900;
      cursor:pointer;
    }

    .slot-note{
      display:none;
    }

    .submit-box{
      margin:18px 0 6px;
      background:#fff;
      border:1px solid #e2e8f0;
      border-radius:16px;
      padding:14px;
      display:flex;
      gap:10px;
      justify-content:center;
      flex-wrap:wrap;
      box-shadow:0 6px 16px rgba(15,23,42,.06);
    }

    .submit-main-btn{
      border:none;
      background:#16a34a;
      color:#fff;
      padding:13px 18px;
      border-radius:14px;
      font-weight:900;
      cursor:pointer;
      width:min(100%,520px);
      min-width:240px;
    }

    .submit-main-btn:disabled,
    .route-action-btn:disabled,
    .add-here-btn:disabled,
    .draft-confirm-btn:disabled,
    .draft-remove-btn:disabled,
    .confirmed-stop-remove:disabled{
      opacity:.55;
      cursor:not-allowed;
    }

    @media(max-width:700px){
      .route-node,
      .insert-zone{
        grid-template-columns:38px 1fr;
        gap:8px;
      }

      .route-dot{
        width:30px;
        height:30px;
        font-size:12px;
      }

      .route-card-head{
        align-items:center;
        flex-direction:row;
      }

      .edit-input-row,
      .draft-stop-row{
        grid-template-columns:1fr;
      }

      .draft-confirm-btn,
      .route-action-btn,
      .submit-main-btn{
        width:100%;
      }

      .draft-remove-btn,
      .confirmed-stop-remove{
        width:100%;
      }
    }
  `;

  document.head.appendChild(style);

})();

/* ================= BASIC HELPERS ================= */

function clean(v){
  return String(v ?? "").trim();
}

function upper(v){
  return clean(v).toUpperCase();
}

function cleanStatus(v){
  return String(v || "")
    .toLowerCase()
    .replace(/\s+/g,"")
    .replace(/-/g,"")
    .replace(/_/g,"")
    .trim();
}

function esc(v){
  return String(v ?? "")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;");
}

function showAlert(type,message){
  if(!alertBox) return;
  alertBox.className = `alert ${type} show`;
  alertBox.textContent = message || "";
}

function hideAlert(){
  if(!alertBox) return;
  alertBox.className = "alert";
  alertBox.textContent = "";
}

function showLoading(){
  if(loadingBox) loadingBox.style.display = "flex";
  if(form) form.style.display = "none";
}

function showForm(){
  if(loadingBox) loadingBox.style.display = "none";
  if(form) form.style.display = "block";
}

function getNowISO(){
  return new Date().toISOString();
}

function goBackToReview(){
  window.location.href = REVIEW_URL;
}

function nextId(){
  uid += 1;
  return String(uid);
}

function setGlobalLoading(isLoading,text){

  document
    .querySelectorAll(
      ".submit-main-btn,.route-action-btn,.add-here-btn,.draft-confirm-btn,.draft-remove-btn,.confirmed-stop-remove"
    )
    .forEach(btn=>{
      btn.disabled = isLoading;
    });

  const submitBtn =
    document.getElementById("submitAddStopRequestBtn");

  if(submitBtn){
    submitBtn.disabled = isLoading;
    submitBtn.textContent = isLoading
      ? (text || "Processing...")
      : getSubmitButtonText();
  }

  if(backBtn){
    backBtn.disabled = isLoading;
  }
}

function totalConfirmedNewStops(){
  return confirmedNewStops.length;
}

function hasExistingEdits(){
  return Object.keys(confirmedExistingEdits).length > 0;
}

function hasRemovedExistingStops(){
  return removedExistingStopIndexes.size > 0;
}

function hasDropoffEdit(){
  return (
    confirmedDropoff !== null &&
    confirmedDropoff !== getEditorDropoff(currentTrip || {})
  );
}

function hasAnyChange(){
  return (
    totalConfirmedNewStops() > 0 ||
    hasExistingEdits() ||
    hasRemovedExistingStops() ||
    hasDropoffEdit()
  );
}

/* ================= SYSTEM ================= */

async function loadSystemDesign(){

  try{

    const res =
      await fetch("/api/system-design");

    const data =
      await res.json().catch(()=>({}));

    SYSTEM_REGION = data?.region || "";
    SYSTEM_COUNTRY = data?.country || "";
    SYSTEM_TIMEZONE = data?.timezone || "America/Phoenix";

  }catch(err){
    console.log("SYSTEM DESIGN ERROR:",err);
  }
}

function normalizeAddress(address){

  let v = clean(address);

  if(!v) return "";

  v = v.replace(/\s+/g," ").trim();

  const lower =
    v.toLowerCase();

  if(SYSTEM_REGION && !lower.includes(SYSTEM_REGION.toLowerCase())){
    v += ", " + SYSTEM_REGION;
  }

  if(SYSTEM_COUNTRY && !lower.includes(SYSTEM_COUNTRY.toLowerCase())){
    v += ", " + SYSTEM_COUNTRY;
  }

  return v;
}

/* ================= TRIP LOADING ================= */

async function fetchTripById(){

  if(!tripId){
    throw new Error("Missing trip ID");
  }

  try{

    const direct =
      await fetch(
        API_TRIP_BY_ID(tripId),
        {
          headers:{
            Authorization:"Bearer " + token
          }
        }
      );

    if(direct.ok){

      const data =
        await direct.json().catch(()=>null);

      if(data && data._id) return data;
      if(data && data.trip && data.trip._id) return data.trip;
    }

  }catch(err){
    console.log("DIRECT TRIP LOAD ERROR:",err);
  }

  const res =
    await fetch(
      API_COMPANY_TRIPS,
      {
        headers:{
          Authorization:"Bearer " + token
        }
      }
    );

  if(!res.ok){
    throw new Error("Failed to load trip");
  }

  const list =
    await res.json().catch(()=>[]);

  if(!Array.isArray(list)){
    throw new Error("Invalid trips response");
  }

  const trip =
    list.find(t => String(t._id) === String(tripId));

  if(!trip){
    throw new Error("Trip not found");
  }

  return trip;
}

async function reloadFreshTrip(){
  currentTrip = await fetchTripById();
  currentTrip = await applyAddStopContext(currentTrip);
  return currentTrip;
}

async function applyAddStopContext(trip){

  const res = await fetch(
    API_ADD_STOP_CONTEXT(tripId),
    {
      method:"GET",
      cache:"no-store",
      headers:{
        Accept:"application/json",
        Authorization:"Bearer " + token
      }
    }
  );

  const data = await res.json().catch(()=>({}));

  if(!res.ok || data.success === false || data.allowed !== true){
    throw new Error(
      data.message ||
      "Add Stop is not available for this trip"
    );
  }

  return {
    ...trip,
    addStopPolicy:data.addStopPolicy || {},
    tripInProgress:data.tripInProgress === true,
    currentStopIndex:Number(data.currentStopIndex || 0),
    completedStopCount:Number(data.completedStopCount || 0),
    driverLocationAtRequest:data.driverLocationAtRequest || null
  };
}

/* ================= TRIP RULES ================= */

function isSharedTrip(trip){

  if(!trip) return false;

  const tripType =
    upper(trip.tripType || trip.type);

  const tripNumber =
    upper(trip.tripNumber);

  const serviceKey =
    upper(
      trip.serviceKey ||
      trip.serviceCode ||
      trip.serviceType ||
      trip.serviceSuffix ||
      trip.vehicle ||
      ""
    );

  return (
    trip.isShared === true ||
    tripType === "SHARED" ||
    tripNumber.includes("-SH") ||
    serviceKey === "SH" ||
    serviceKey === "SHARED"
  );
}

function tripIsClosed(trip){

  const s =
    cleanStatus(trip?.status);

  return (
    s.includes("complete") ||
    s.includes("cancel") ||
    s.includes("noshow") ||
    s.includes("notcompleted")
  );
}

function tripIsInProgress(trip){

  const s =
    cleanStatus(trip?.status);

  return [
    "ontrip",
    "started",
    "inprogress",
    "pickedup",
    "pickupcompleted",
    "passengerpickedup",
    "enroute",
    "active"
  ].includes(s);
}

function getCompletedStopCount(trip,totalStops){

  const directCount = Number(trip?.completedStopCount);
  const currentStopIndex = Number(trip?.currentStopIndex);

  const count =
    Number.isInteger(directCount) && directCount >= 0
      ? directCount
      : Number.isInteger(currentStopIndex) && currentStopIndex >= 0
        ? Math.max(0,currentStopIndex - 1)
        : 0;

  return Math.max(
    0,
    Math.min(Number(totalStops || 0),count)
  );
}

function existingStopIsCompleted(trip,index){
  return (
    tripIsInProgress(trip) &&
    Number(index) < getCompletedStopCount(
      trip,
      getExistingStops(trip).length
    )
  );
}

function getClientName(trip){
  return (
    trip.clientName ||
    trip.name ||
    trip.customerName ||
    ""
  );
}

function getPickup(trip){
  return clean(
    trip.pickup ||
    trip.pickupAddress ||
    ""
  );
}

function getDropoff(trip){
  return clean(
    trip.dropoff ||
    trip.dropoffAddress ||
    ""
  );
}

function getFinalDropoff(){
  return confirmedDropoff !== null
    ? confirmedDropoff
    : getEditorDropoff(currentTrip || {});
}

function getStoredStops(trip){

  if(!Array.isArray(trip.stops)){
    return [];
  }

  return trip.stops
    .map(s => {

      if(typeof s === "string"){
        return normalizeAddress(s);
      }

      return normalizeAddress(
        s?.address ||
        s?.stopAddress ||
        s?.fullAddress ||
        s?.formattedAddress ||
        s?.formatted_address ||
        s?.description ||
        s?.location ||
        s?.label ||
        ""
      );
    })
    .filter(Boolean);
}

function getActiveCompanyRequest(trip){

  if(!hasActiveStopRequest(trip)){
    return null;
  }

  const request =
    trip?.addStopRequest || null;

  return clean(request?.source).toLowerCase() === "company-add-stop"
    ? request
    : null;
}

function getEditorDropoff(trip){

  const request =
    getActiveCompanyRequest(trip);

  return clean(
    request?.dropoffAfter ||
    request?.dropoffBefore ||
    getDropoff(trip)
  );
}

function getExistingStops(trip){

  const request =
    getActiveCompanyRequest(trip);

  if(Array.isArray(request?.finalStops)){
    return request.finalStops
      .map(s=>normalizeAddress(s))
      .filter(Boolean);
  }

  return getStoredStops(trip);
}

function getEditedExistingStops(trip){

  const original =
    getExistingStops(trip);

  return original
    .map((stop,index)=>({stop,index}))
    .filter(item=>
      !removedExistingStopIndexes.has(item.index)
    )
    .map(item=>{
      return confirmedExistingEdits[item.index] || item.stop;
    });
}

function hasActiveStopRequest(trip){

  const req =
    trip?.addStopRequest || {};

  const status =
    upper(req.status || "");

  return (
    req.active === true &&
    ![
      "CANCELLED",
      "CANCELLED_BY_COMPANY",
      "CANCELLED_BY_CUSTOMER",
      "COMPLETED",
      "STOP_REACHED"
    ].includes(status)
  );
}

/* ================= GOOGLE ================= */

async function ensureGoogleLoaded(){

  if(window.google && google.maps && google.maps.DirectionsService){
    return;
  }

  if(googleLoadPromise){
    return googleLoadPromise;
  }

  googleLoadPromise =
    new Promise(async (resolve,reject)=>{

      try{

        const res =
          await fetch("/api/config");

        const data =
          await res.json().catch(()=>({}));

        if(!data.googleKey){
          reject(new Error("Google key missing"));
          return;
        }

        const existing =
          document.querySelector("script[data-google-maps='true']");

        if(existing){

          if(window.google && google.maps && google.maps.DirectionsService){
            resolve();
            return;
          }

          existing.addEventListener("load",()=>resolve());
          existing.addEventListener("error",()=>reject(new Error("Google failed")));
          return;
        }

        const script = document.createElement("script");
        script.src = `https://maps.googleapis.com/maps/api/js?key=${data.googleKey}`;
        script.async = true;
        script.defer = true;
        script.setAttribute("data-google-maps","true");
        script.onload = ()=>resolve();
        script.onerror = ()=>reject(new Error("Google failed"));

        document.head.appendChild(script);

      }catch(err){
        reject(err);
      }
    });

  return googleLoadPromise;
}

function isLatLngPoint(p){
  return (
    p &&
    typeof p === "object" &&
    Number.isFinite(Number(p.lat)) &&
    Number.isFinite(Number(p.lng))
  );
}

function normalizeRoutePoint(p){

  if(isLatLngPoint(p)){
    return {
      lat:Number(p.lat),
      lng:Number(p.lng)
    };
  }

  return normalizeAddress(p);
}

function pointIsValid(p){
  if(isLatLngPoint(p)) return true;
  return !!clean(p);
}

async function calculateRouteMiles(points){

  await ensureGoogleLoaded();

  const cleanPoints =
    Array.isArray(points)
      ? points.map(normalizeRoutePoint).filter(pointIsValid)
      : [];

  if(cleanPoints.length < 2){
    return {
      miles:0,
      distanceMeters:0,
      durationSeconds:0,
      estimatedMinutes:0,
      googleRoute:{}
    };
  }

  const origin =
    cleanPoints[0];

  const destination =
    cleanPoints[cleanPoints.length - 1];

  const middle =
    cleanPoints.slice(1,-1);

  const waypoints =
    middle.map(point=>({
      location:point,
      stopover:true
    }));

  return new Promise((resolve,reject)=>{

    const service =
      new google.maps.DirectionsService();

    service.route(
      {
        origin,
        destination,
        waypoints,
        optimizeWaypoints:false,
        travelMode:google.maps.TravelMode.DRIVING,
        unitSystem:google.maps.UnitSystem.IMPERIAL
      },
      function(response,status){

        if(status !== "OK" || !response?.routes?.[0]){
          reject(new Error("Google route failed: " + status));
          return;
        }

        const route =
          response.routes[0];

        let meters = 0;
        let seconds = 0;

        route.legs.forEach(leg=>{
          meters += leg.distance ? leg.distance.value : 0;
          seconds += leg.duration ? leg.duration.value : 0;
        });

        resolve({
          miles:Number((meters * 0.000621371).toFixed(2)),
          distanceMeters:meters,
          durationSeconds:seconds,
          estimatedMinutes:Math.ceil(seconds / 60),
          googleRoute:{
            summary:route.summary || "",
            legs:route.legs.map((leg,index)=>({
              legIndex:index,
              startAddress:leg.start_address,
              endAddress:leg.end_address,
              distanceText:leg.distance ? leg.distance.text : "",
              distanceMeters:leg.distance ? leg.distance.value : 0,
              durationText:leg.duration ? leg.duration.text : "",
              durationSeconds:leg.duration ? leg.duration.value : 0
            }))
          }
        });
      }
    );
  });
}

/* ================= DRIVER LOCATION ================= */

function extractLatLngFromObject(obj){

  if(!obj || typeof obj !== "object"){
    return null;
  }

  const directLat =
    obj.lat ??
    obj.latitude ??
    obj.driverLat ??
    obj.currentLat ??
    obj.locationLat;

  const directLng =
    obj.lng ??
    obj.lon ??
    obj.long ??
    obj.longitude ??
    obj.driverLng ??
    obj.currentLng ??
    obj.locationLng;

  if(
    Number.isFinite(Number(directLat)) &&
    Number.isFinite(Number(directLng))
  ){
    return {
      lat:Number(directLat),
      lng:Number(directLng)
    };
  }

  const containers = [
    obj.location,
    obj.currentLocation,
    obj.driverLocation,
    obj.liveLocation,
    obj.coords,
    obj.position,
    obj.assignment,
    obj.driver,
    obj.data
  ];

  for(const item of containers){
    const found =
      extractLatLngFromObject(item);

    if(found) return found;
  }

  return null;
}

function getDriverLocationFromTrip(trip){
  return extractLatLngFromObject(trip);
}

async function fetchDriverLocationFromServer(id){

  try{

    const res =
      await fetch("/api/admin/live-drivers",{cache:"no-store",headers:{Authorization:"Bearer " + token}});

    if(!res.ok){
      return null;
    }

    const list =
      await res.json().catch(()=>[]);

    if(!Array.isArray(list)){
      return null;
    }

    const trip =
      currentTrip || {};

    const tripObjectId =
      String(trip._id || id || tripId || "");

    const tripDriverId =
      String(
        trip.driverId ||
        trip.driver ||
        trip.assignedDriverId ||
        ""
      );

    const found =
      list.find(d=>{

        const liveTripId =
          String(d.tripId || "");

        const liveDriverId =
          String(d.driverId || "");

        return (
          liveTripId === tripObjectId ||
          liveTripId === String(tripId || "") ||
          (
            tripDriverId &&
            liveDriverId === tripDriverId
          )
        );

      });

    if(!found){
      return null;
    }

    return extractLatLngFromObject(found);

  }catch(err){

    console.log("LIVE DRIVER LOCATION ERROR:",err);
    return null;

  }
}

async function getFreshDriverLocation(trip){

  const fromContext =
    extractLatLngFromObject(
      trip?.driverLocationAtRequest
    );

  if(fromContext) return fromContext;

  const fromTrip =
    getDriverLocationFromTrip(trip);

  if(fromTrip) return fromTrip;

  return await fetchDriverLocationFromServer(tripId);
}

/* ================= UI ROOT ================= */

function hideOldControls(){

  if(addStopBtn){
    addStopBtn.classList.add("old-add-stop-hidden");
  }

  if(confirmAddStopBtn){
    confirmAddStopBtn.classList.add("old-add-stop-hidden");
  }
}

function getEditorRoot(){

  let root =
    document.getElementById("routeEditorRoot");

  if(root) return root;

  root =
    document.createElement("div");

  root.id =
    "routeEditorRoot";

  root.className =
    "route-editor";

  if(stopsContainer){
    stopsContainer.innerHTML = "";
    stopsContainer.appendChild(root);
  }else if(form){
    form.appendChild(root);
  }

  return root;
}

function ensureSubmitBox(){

  let box =
    document.getElementById("submitAddStopBox");

  if(!box){

    box =
      document.createElement("div");

    box.id =
      "submitAddStopBox";

    box.className =
      "submit-box";

    box.innerHTML = `
      <button
        type="button"
        id="submitAddStopRequestBtn"
        class="submit-main-btn"
      >
        Submit Add Stop Request
      </button>
    `;

    const root =
      getEditorRoot();

    root.insertAdjacentElement("afterend",box);
  }

  const btn =
    document.getElementById("submitAddStopRequestBtn");

  if(btn && !btn.dataset.bound){

    btn.dataset.bound = "true";

    btn.addEventListener("click",function(e){

      e.preventDefault();
      e.stopPropagation();

      finalSubmitAddStop();

    });
  }

  return box;
}

function getSubmitButtonText(){
  return "Save Route Changes";
}

function updateSubmitButtonState(){

  const btn =
    document.getElementById("submitAddStopRequestBtn");

  if(!btn) return;

  btn.textContent =
    getSubmitButtonText();

  btn.disabled = !hasAnyChange();
}

/* ================= UI RENDER HELPERS ================= */

function renderRoutePoint({type,label,value,index,dataIndex=null,isLast,editable=false,edited=false,completed=false}){

  const icon =
    type === "pickup"
      ? "P"
      : type === "dropoff"
        ? "D"
        : String(index);

  const isEditing =
    (
      type === "stop" &&
      Number(editingExistingIndex) === Number(dataIndex)
    ) ||
    (
      type === "dropoff" &&
      editingDropoff === true
    );

  const editButton =
    editable
      ? `
        <div class="route-actions">
          <button
            type="button"
            class="route-action-btn edit"
            data-action="${type === "dropoff" ? "edit-dropoff" : "edit-existing"}"
            data-index="${type === "stop" ? dataIndex : index - 1}"
          >
            Edit
          </button>

          ${
            type === "stop"
              ? `
                <button
                  type="button"
                  class="route-action-btn delete"
                  data-action="remove-existing-stop"
                  data-index="${dataIndex}"
                >
                  Delete
                </button>
              `
              : ""
          }
        </div>
      `
      : "";

  return `
    <div class="route-node">
      <div class="route-dot-wrap">
        <div class="route-dot ${type}">${esc(icon)}</div>
        ${isLast ? "" : `<div class="route-line"></div>`}
      </div>

      <div class="route-card">
        <div class="route-card-head">
          <div class="route-card-head-left">
            <div>${esc(label)}</div>
            ${edited ? `<span class="edited">EDITED</span>` : ""}
            ${completed ? `<span class="edited">COMPLETED</span>` : ""}
          </div>

          ${editButton}
        </div>

        ${
          isEditing
            ? ""
            : `
              <div class="route-address">
                ${esc(value || "--")}
              </div>
            `
        }

        ${renderInlineEditBox(type,index,value,dataIndex)}
      </div>
    </div>
  `;
}

function renderInlineEditBox(type,index,value,dataIndex=null){

  if(type === "stop"){

    const stopIndex =
      Number(dataIndex);

    if(Number(editingExistingIndex) !== Number(stopIndex)){
      return "";
    }

    const draft =
      existingEditDrafts[stopIndex] ?? value ?? "";

    return `
      <div class="edit-box">
        <div class="edit-input-row">
          <input
            type="text"
            class="edit-input existing-edit-input"
            data-index="${stopIndex}"
            value="${esc(draft)}"
            placeholder="Edit existing stop address"
          >

          <button
            type="button"
            class="route-action-btn confirm"
            data-action="confirm-existing-edit"
            data-index="${stopIndex}"
          >
            Save
          </button>

          <button
            type="button"
            class="route-action-btn cancel"
            data-action="cancel-existing-edit"
            data-index="${stopIndex}"
          >
            Cancel
          </button>
        </div>
      </div>
    `;
  }

  if(type === "dropoff" && editingDropoff){

    const draft =
      dropoffDraft || value || "";

    return `
      <div class="edit-box">
        <div class="edit-input-row">
          <input
            type="text"
            class="edit-input dropoff-edit-input"
            value="${esc(draft)}"
            placeholder="Edit dropoff address"
          >

          <button
            type="button"
            class="route-action-btn confirm"
            data-action="confirm-dropoff-edit"
          >
            Save
          </button>

          <button
            type="button"
            class="route-action-btn cancel"
            data-action="cancel-dropoff-edit"
          >
            Cancel
          </button>
        </div>
      </div>
    `;
  }

  return "";
}

function getDraftsForSlot(slotIndex,rowIndex=null){
  return newStopDrafts
    .filter(s =>
      Number(s.insertAfterIndex) === Number(slotIndex) &&
      (
        rowIndex === null ||
        Number(s.rowIndex || 0) === Number(rowIndex)
      )
    );
}

function getConfirmedNewStopsForSlot(slotIndex){
  return confirmedNewStops
    .filter(s => Number(s.insertAfterIndex) === Number(slotIndex))
    .sort((a,b)=>Number(a.rowIndex || 0) - Number(b.rowIndex || 0));
}

function renderDraftRows(slotIndex,rowIndex){

  const drafts =
    getDraftsForSlot(slotIndex,rowIndex);

  if(!drafts.length){
    return "";
  }

  return drafts.map(draft=>`
    <div class="draft-stop-row" data-draft-id="${esc(draft.id)}">
      <input
        type="text"
        class="draft-stop-input"
        data-id="${esc(draft.id)}"
        value="${esc(draft.value || "")}"
        placeholder="Enter new stop address"
      >

      <button
        type="button"
        class="draft-confirm-btn"
        data-action="confirm-new-stop"
        data-id="${esc(draft.id)}"
      >
        Add
      </button>

      <button
        type="button"
        class="draft-remove-btn"
        data-action="remove-draft-stop"
        data-id="${esc(draft.id)}"
        title="Remove"
      >
        Cancel
      </button>
    </div>
  `).join("");
}

function renderConfirmedNewStop(stop){
  return `
    <div class="confirmed-stop-chip" data-stop-id="${esc(stop.id)}">
      <div class="confirmed-stop-text">
        ${esc(stop.address)}
      </div>

      <button
        type="button"
        class="confirmed-stop-remove"
        data-action="remove-confirmed-new-stop"
        data-id="${esc(stop.id)}"
        title="Remove"
      >
        Delete
      </button>
    </div>
  `;
}

function getCurrentStopCount(){
  return (
    getEditedExistingStops(currentTrip || {}).length +
    totalConfirmedNewStops() +
    newStopDrafts.length
  );
}

function renderAddHereButton(slotIndex,rowIndex){

  const cannotAdd =
    getCurrentStopCount() >= MAX_STOPS;

  const hasDraft =
    getDraftsForSlot(slotIndex,rowIndex).length > 0;

  if(hasDraft){
    return "";
  }

  return `
    <button
      type="button"
      class="add-here-btn"
      data-action="add-draft-stop"
      data-slot="${slotIndex}"
      data-row="${rowIndex}"
      ${cannotAdd ? "disabled" : ""}
    >
      <span>+</span>
      Add Stop Here
    </button>
  `;
}

function renderInsertZone(slotIndex,label){

  const confirmed =
    getConfirmedNewStopsForSlot(slotIndex);

  let slotContent = "";

  for(let rowIndex = 0; rowIndex <= confirmed.length; rowIndex++){
    slotContent += renderAddHereButton(slotIndex,rowIndex);
    slotContent += renderDraftRows(slotIndex,rowIndex);

    if(rowIndex < confirmed.length){
      slotContent += renderConfirmedNewStop(confirmed[rowIndex]);
    }
  }

  return `
    <div class="insert-zone" data-slot="${slotIndex}">
      <div class="insert-line-wrap">
        <div class="insert-line"></div>
      </div>

      <div class="insert-content">
        <div class="slot-area">
          ${slotContent}
        </div>

        <div class="slot-note">
          ${esc(label)}
        </div>
      </div>
    </div>
  `;
}

/* ================= MAIN RENDER ================= */

function renderRouteEditor(trip){

  const root =
    getEditorRoot();

  const pickup =
    getPickup(trip);

  const dropoffOriginal =
    getDropoff(trip);

  const finalDropoff =
    getFinalDropoff();

  const existingOriginal =
    getExistingStops(trip);

  const existingOriginalEntries =
    getExistingStops(trip)
      .map((address,originalIndex)=>({
        address,
        originalIndex
      }));

  const existingEditedEntries =
    existingOriginalEntries
      .filter(entry=>
        !removedExistingStopIndexes.has(entry.originalIndex)
      )
      .map(entry=>({
        ...entry,
        address:
          confirmedExistingEdits[entry.originalIndex] ||
          entry.address
      }));

  const existingEdited =
    existingEditedEntries.map(entry=>entry.address);

  const completedStopCount =
    getCompletedStopCount(
      trip,
      existingOriginal.length
    );

  const points = [];

  points.push({
    type:"pickup",
    label:"Pickup",
    value:pickup,
    index:0,
    editable:false,
    edited:false
  });

  existingEditedEntries.forEach((entry,index)=>{

    const completed =
      existingStopIsCompleted(
        trip,
        entry.originalIndex
      );

    points.push({
      type:"stop",
      label:`Stop ${index + 1}`,
      value:entry.address,
      index:index + 1,
      dataIndex:entry.originalIndex,
      editable:!completed,
      completed,
      edited:
        entry.address !==
        existingOriginal[entry.originalIndex]
    });
  });

  points.push({
    type:"dropoff",
    label:"Dropoff",
    value:finalDropoff,
    index:existingEdited.length + 1,
    editable:true,
    edited:finalDropoff !== dropoffOriginal
  });

  let body = "";

  points.forEach((point,index)=>{

    const isLast =
      index === points.length - 1;

    body += renderRoutePoint({
      ...point,
      isLast
    });

    if(
      !isLast &&
      (
        !tripIsInProgress(trip) ||
        index >= completedStopCount
      )
    ){

      let label = "";

      if(index === 0){
        label = existingEdited.length
          ? "Stops added here will be placed after Pickup and before Existing Stop 1."
          : "Stops added here will be placed before Dropoff.";
      }else{
        label = index === existingEdited.length
          ? `Stops added here will be placed after Existing Stop ${index} and before Dropoff.`
          : `Stops added here will be placed after Existing Stop ${index} and before Existing Stop ${index + 1}.`;
      }

      body += renderInsertZone(index,label);
    }
  });

  root.innerHTML = `
    <div class="route-editor-head">
      <div class="route-editor-title">
        Current Route
      </div>

      <div class="route-editor-badge">
        ${existingEdited.length + totalConfirmedNewStops()} Stop${existingEdited.length + totalConfirmedNewStops() === 1 ? "" : "s"}
      </div>
    </div>

    <div class="route-editor-body">
      ${body}
    </div>
  `;

  ensureSubmitBox();
  updateSubmitButtonState();
}

function rerender(){
  renderRouteEditor(currentTrip || {});
}

/* ================= ADD NEW STOP ACTIONS ================= */

function addDraftStop(slotIndex,rowIndex){

  hideAlert();

  const completedStopCount =
    getCompletedStopCount(
      currentTrip || {},
      getExistingStops(currentTrip || {}).length
    );

  if(
    tripIsInProgress(currentTrip || {}) &&
    Number(slotIndex) < completedStopCount
  ){
    showAlert(
      "error",
      "New stops cannot be inserted before completed stops."
    );
    return;
  }

  const total =
    getCurrentStopCount();

  if(total >= MAX_STOPS){
    showAlert("error",`Maximum ${MAX_STOPS} total stops allowed`);
    return;
  }

  const id =
    nextId();

  newStopDrafts.push({
    id,
    insertAfterIndex:Number(slotIndex || 0),
    rowIndex:Number(rowIndex || 0),
    value:""
  });

  rerender();

  setTimeout(()=>{
    const input =
      document.querySelector(`.draft-stop-input[data-id="${id}"]`);

    if(input) input.focus();
  },30);
}

function updateDraftValue(id,value){

  const item =
    newStopDrafts.find(s => String(s.id) === String(id));

  if(item){
    item.value = value;
  }
}

function removeDraftStop(id){

  newStopDrafts =
    newStopDrafts.filter(s => String(s.id) !== String(id));

  hideAlert();
  rerender();
}

function confirmNewStop(id){

  hideAlert();

  const draft =
    newStopDrafts.find(s => String(s.id) === String(id));

  if(!draft) return;

  const input =
    document.querySelector(`.draft-stop-input[data-id="${id}"]`);

  const raw =
    input ? input.value : draft.value;

  const address =
    normalizeAddress(raw);

  if(!address){
    showAlert("error","Please enter stop address first");
    if(input) input.focus();
    return;
  }

  const duplicate =
    confirmedNewStops.some(s =>
      clean(s.address).toLowerCase() === address.toLowerCase()
    );

  if(duplicate){
    showAlert("error","This stop is already confirmed");
    if(input) input.focus();
    return;
  }

  const slotIndex =
    Number(draft.insertAfterIndex || 0);

  const rowIndex =
    Number(draft.rowIndex || 0);

  confirmedNewStops
    .filter(s =>
      Number(s.insertAfterIndex) === slotIndex &&
      Number(s.rowIndex || 0) >= rowIndex
    )
    .forEach(s=>{
      s.rowIndex = Number(s.rowIndex || 0) + 1;
    });

  newStopDrafts
    .filter(s =>
      String(s.id) !== String(id) &&
      Number(s.insertAfterIndex) === slotIndex &&
      Number(s.rowIndex || 0) >= rowIndex
    )
    .forEach(s=>{
      s.rowIndex = Number(s.rowIndex || 0) + 1;
    });

  confirmedNewStops.push({
    id:nextId(),
    address,
    insertAfterIndex:slotIndex,
    rowIndex
  });

  newStopDrafts =
    newStopDrafts.filter(s => String(s.id) !== String(id));

  rerender();
}

function removeConfirmedNewStop(id){

  const removed =
    confirmedNewStops.find(s => String(s.id) === String(id));

  const slotIndex =
    removed ? Number(removed.insertAfterIndex || 0) : null;

  const removedRowIndex =
    removed ? Number(removed.rowIndex || 0) : null;

  confirmedNewStops =
    confirmedNewStops.filter(s => String(s.id) !== String(id));

  if(slotIndex !== null){
    const slotStops =
      confirmedNewStops
        .filter(s => Number(s.insertAfterIndex) === slotIndex)
        .sort((a,b)=>Number(a.rowIndex || 0) - Number(b.rowIndex || 0));

    slotStops.forEach((s,index)=>{
      s.rowIndex = index;
    });

    newStopDrafts
      .filter(s =>
        Number(s.insertAfterIndex) === slotIndex &&
        Number(s.rowIndex || 0) > removedRowIndex
      )
      .forEach(s=>{
        s.rowIndex = Number(s.rowIndex || 0) - 1;
      });
  }

  hideAlert();
  rerender();
}

/* ================= EXISTING STOP EDIT ================= */

function startExistingEdit(index){

  hideAlert();

  if(existingStopIsCompleted(currentTrip || {},index)){
    showAlert("error","Completed stops cannot be edited or deleted.");
    return;
  }

  editingExistingIndex =
    Number(index);

  const stops =
    getEditedExistingStops(currentTrip || {});

  existingEditDrafts[index] =
    confirmedExistingEdits[index] ||
    stops[index] ||
    "";

  rerender();

  setTimeout(()=>{
    const input =
      document.querySelector(`.existing-edit-input[data-index="${index}"]`);

    if(input) input.focus();
  },30);
}

function confirmExistingEdit(index){

  hideAlert();

  const input =
    document.querySelector(`.existing-edit-input[data-index="${index}"]`);

  const value =
    normalizeAddress(input?.value || "");

  if(!value){
    showAlert("error","Existing stop address cannot be empty");
    if(input) input.focus();
    return;
  }

  const original =
    getExistingStops(currentTrip || {})[index] || "";

  if(value === original){
    delete confirmedExistingEdits[index];
  }else{
    confirmedExistingEdits[index] = value;
  }

  delete existingEditDrafts[index];
  editingExistingIndex = null;

  rerender();
}

function cancelExistingEdit(index){

  delete existingEditDrafts[index];
  editingExistingIndex = null;

  hideAlert();
  rerender();
}

function removeExistingStop(index){

  const originalIndex =
    Number(index);

  if(existingStopIsCompleted(currentTrip || {},originalIndex)){
    showAlert("error","Completed stops cannot be edited or deleted.");
    return;
  }

  const stop =
    getExistingStops(currentTrip || {})[originalIndex] || "";

  if(!stop){
    showAlert("error","Stop not found");
    return;
  }

  if(!window.confirm("Remove this stop from the route?")){
    return;
  }

  removedExistingStopIndexes.add(originalIndex);
  delete confirmedExistingEdits[originalIndex];
  delete existingEditDrafts[originalIndex];

  if(Number(editingExistingIndex) === originalIndex){
    editingExistingIndex = null;
  }

  hideAlert();
  rerender();
}

/* ================= DROPOFF EDIT ================= */

function startDropoffEdit(){

  hideAlert();

  editingDropoff = true;
  dropoffDraft = getFinalDropoff();

  rerender();

  setTimeout(()=>{
    const input =
      document.querySelector(".dropoff-edit-input");

    if(input) input.focus();
  },30);
}

function confirmDropoffEdit(){

  hideAlert();

  const input =
    document.querySelector(".dropoff-edit-input");

  const value =
    normalizeAddress(input?.value || "");

  if(!value){
    showAlert("error","Dropoff address cannot be empty");
    if(input) input.focus();
    return;
  }

  const original =
    getEditorDropoff(currentTrip || {});

  confirmedDropoff =
    value === original ? null : value;

  dropoffDraft = "";
  editingDropoff = false;

  rerender();
}

function cancelDropoffEdit(){

  dropoffDraft = "";
  editingDropoff = false;

  hideAlert();
  rerender();
}

/* ================= ROUTE BUILD ================= */

function buildFinalStops(originalExistingStops,addedStopObjects){

  const oldStops =
    Array.isArray(originalExistingStops)
      ? originalExistingStops.filter(Boolean)
      : [];

  const editedStops =
    oldStops
      .map((stop,index)=>({stop,index}))
      .filter(item=>
        !removedExistingStopIndexes.has(item.index)
      )
      .map(item=>{
        return confirmedExistingEdits[item.index] || item.stop;
      });

  const added =
    Array.isArray(addedStopObjects)
      ? addedStopObjects.filter(s => s && s.address)
      : [];

  const finalStops = [];

  for(let anchorIndex = 0; anchorIndex <= editedStops.length; anchorIndex++){

    if(anchorIndex > 0){
      finalStops.push(editedStops[anchorIndex - 1]);
    }

    added
      .filter(s => Number(s.insertAfterIndex || 0) === anchorIndex)
      .sort((a,b)=>Number(a.rowIndex || 0) - Number(b.rowIndex || 0))
      .forEach(s=>{
        finalStops.push(s.address);
      });
  }

  return finalStops;
}

function buildOriginalRouteBeforeStart(trip){

  return [
    getPickup(trip),
    ...getExistingStops(trip),
    getDropoff(trip)
  ].filter(Boolean);
}

function buildNewRouteBeforeStart(trip,finalStops,dropoffAfter){

  return [
    getPickup(trip),
    ...finalStops,
    dropoffAfter
  ].filter(Boolean);
}

function sameRouteAddress(first,second){
  return clean(first).toLowerCase() === clean(second).toLowerCase();
}

/* ================= CALCULATION ================= */

async function calculateFinalRouteChange(trip,addedStopObjects){

  const pickup = getPickup(trip);
  const dropoffBefore = getDropoff(trip);
  const dropoffAfter = getFinalDropoff();

  const existingStopsBefore = getStoredStops(trip);

  const editorStopsBefore = getExistingStops(trip);

  const editedExistingStops =
    getEditedExistingStops(trip);

  const finalStops = buildFinalStops(
    editorStopsBefore,
    addedStopObjects
  );

  const inProgress = tripIsInProgress(trip);

  let mode = "BEFORE_START";
  let driverLocationAtConfirm = null;

  let originalRoutePoints = [];
  let newRoutePoints = [];

  if(inProgress){

    mode = "IN_PROGRESS";

    driverLocationAtConfirm =
      await getFreshDriverLocation(trip);

    if(!driverLocationAtConfirm){
      throw new Error("Driver current location is missing");
    }

    const completedStopCount =
      getCompletedStopCount(
        trip,
        existingStopsBefore.length
      );

    const completedStops =
      existingStopsBefore.slice(0,completedStopCount);

    const submittedCompletedStops =
      finalStops.slice(0,completedStopCount);

    if(
      submittedCompletedStops.length !== completedStops.length ||
      !completedStops.every(
        (stop,index)=>sameRouteAddress(
          stop,
          submittedCompletedStops[index]
        )
      )
    ){
      throw new Error(
        "Completed stops cannot be edited, deleted, or reordered."
      );
    }

    originalRoutePoints = [
      pickup,
      ...completedStops,
      driverLocationAtConfirm,
      ...existingStopsBefore.slice(completedStopCount),
      dropoffBefore
    ].filter(Boolean);

    newRoutePoints = [
      pickup,
      ...completedStops,
      driverLocationAtConfirm,
      ...finalStops.slice(completedStopCount),
      dropoffAfter
    ].filter(Boolean);

  }else{

    originalRoutePoints =
      buildOriginalRouteBeforeStart(trip);

    newRoutePoints =
      buildNewRouteBeforeStart(
        trip,
        finalStops,
        dropoffAfter
      );
  }

  const originalRoute =
    await calculateRouteMiles(originalRoutePoints);

  const newRoute =
    await calculateRouteMiles(newRoutePoints);

  const extraMiles =
    Number(
      (
        Number(newRoute.miles || 0) -
        Number(originalRoute.miles || 0)
      ).toFixed(2)
    );

  return {
    mode,
    driverLocationAtConfirm,

    pickup,
    dropoffBefore,
    dropoffAfter,

    existingStopsBefore,
    editedExistingStops,

    addedStops: addedStopObjects.map(s => s.address),
    addedStopsDetailed: addedStopObjects,

    finalStops,

    originalRoutePoints,
    newRoutePoints,
    finalRoutePoints: newRoutePoints,

    originalRemainingMiles:originalRoute.miles,
    newRemainingMiles:newRoute.miles,

    extraMiles,

    originalRouteData:originalRoute,
    newRouteData:newRoute
  };
}

/* ================= SERVER SEND ================= */

async function notifyServerAddStop(payload){

  const res =
    await fetch(
      API_ADD_STOP_CONFIRM(tripId),
      {
        method:"POST",
        headers:{
          "Content-Type":"application/json",
          Authorization:"Bearer " + token
        },
        body:JSON.stringify(payload)
      }
    );

  const data =
    await res.json().catch(()=>({}));

  if(!res.ok || data.success === false){
    throw new Error(
      data.message ||
      "Failed to send added stop request"
    );
  }

  return data;
}

/* ================= FINAL SUBMIT ================= */

async function finalSubmitAddStop(){

  hideAlert();

  try{

    if(newStopDrafts.length){
      throw new Error("You have unconfirmed stop fields. Confirm or remove them first.");
    }

    if(!hasAnyChange()){
      throw new Error("No changes to submit");
    }

    setGlobalLoading(true,"Checking trip...");

    const freshTrip =
      await reloadFreshTrip();

    currentTrip =
      freshTrip;

    if(isSharedTrip(freshTrip)){
      throw new Error("Add Stop is not available for shared trips");
    }

    if(tripIsClosed(freshTrip)){
      throw new Error("This trip is closed and cannot be modified");
    }

    const addedStopObjects =
      confirmedNewStops.map((s,index)=>({
        address:s.address,
        insertAfterIndex:Number(s.insertAfterIndex || 0),
        rowIndex:Number(s.rowIndex ?? index)
      }));

    setGlobalLoading(true,"Calculating miles...");

    const calc =
      await calculateFinalRouteChange(
        freshTrip,
        addedStopObjects
      );

    setGlobalLoading(true,"Sending request...");

    const payload = {
      tripId:String(freshTrip._id || tripId),

      source:"company-add-stop",
      requestType:"ROUTE_CHANGE",

      status:"PENDING_REVIEW",
      active:true,
      calculatePriceOnReview:true,

      companyName,
      tripNumber:freshTrip.tripNumber || "",
      clientName:getClientName(freshTrip),

      tripStatusAtConfirm:freshTrip.status || "",
      confirmedAt:getNowISO(),

      mode:calc.mode,
      maxStops:MAX_STOPS,

      pickup:calc.pickup,

      dropoffBefore:calc.dropoffBefore,
      dropoffAfter:calc.dropoffAfter,

      existingStopsBefore:calc.existingStopsBefore,
      editedExistingStops:calc.editedExistingStops,

      addedStops:calc.addedStops,
      addedStopsDetailed:calc.addedStopsDetailed,

      finalStops:calc.finalStops,
      finalRoutePoints:calc.finalRoutePoints,

      driverLocationAtConfirm:
        calc.driverLocationAtConfirm,

      beforeStopChange:{
        pickup:getPickup(freshTrip),
        dropoff:getDropoff(freshTrip),
        stops:calc.existingStopsBefore,
        routePoints:Array.isArray(freshTrip.routePoints)
          ? freshTrip.routePoints
          : [],
        miles:Number(freshTrip.miles || 0),
        priceAmount:Number(freshTrip.priceAmount || 0),
        finalPrice:Number(freshTrip.finalPrice || 0)
      },

      originalRoutePoints:
        calc.originalRoutePoints,

      newRoutePoints:
        calc.newRoutePoints,

      originalRemainingMiles:
        calc.originalRemainingMiles,

      newRemainingMiles:
        calc.newRemainingMiles,

      extraMiles:
        calc.extraMiles,

      originalRouteData:
        calc.originalRouteData,

      newRouteData:
        calc.newRouteData
    };

    const result =
      await notifyServerAddStop(payload);

    showAlert(
      "success",
      result?.cancelled === true
        ? "Route change request cancelled."
        : "Route change request updated and sent to Review."
    );

    setTimeout(()=>{
      goBackToReview();
    },700);

  }catch(err){

    console.error(err);

    showAlert(
      "error",
      err.message || "Failed to submit route change"
    );

  }finally{

    setGlobalLoading(false);
    updateSubmitButtonState();
  }
}

/* ================= PAGE FILL ================= */

function fillPage(trip){

  if(tripNumberInput){
    tripNumberInput.value = trip.tripNumber || "";
  }

  if(clientNameInput){
    clientNameInput.value = getClientName(trip) || "";
  }

  if(pickupAddressInput){
    pickupAddressInput.value = getPickup(trip) || "";
  }

  if(dropoffAddressInput){
    dropoffAddressInput.value = getEditorDropoff(trip) || "";
  }

  renderRouteEditor(trip);

  if(pageStatusBadge){
    pageStatusBadge.textContent =
      hasActiveStopRequest(trip)
        ? "Stop Request Active"
        : "Route Change Request";
  }

  if(hasActiveStopRequest(trip)){
    showAlert(
      "info",
      "Update the pending route by adding, editing, or removing stops. Saving the original route cancels the request."
    );
  }

  updateSubmitButtonState();
}

/* ================= EVENTS ================= */

if(backBtn){
  backBtn.addEventListener("click",()=>{
    goBackToReview();
  });
}

if(form){
  form.addEventListener("submit",e=>{
    e.preventDefault();
    finalSubmitAddStop();
  });
}

document.addEventListener("input",e=>{

  const draftInput =
    e.target.closest(".draft-stop-input");

  if(draftInput){
    updateDraftValue(
      draftInput.dataset.id || "",
      draftInput.value || ""
    );
    return;
  }

  const existingInput =
    e.target.closest(".existing-edit-input");

  if(existingInput){
    existingEditDrafts[existingInput.dataset.index] =
      existingInput.value || "";
    return;
  }

  const dropoffInput =
    e.target.closest(".dropoff-edit-input");

  if(dropoffInput){
    dropoffDraft = dropoffInput.value || "";
    return;
  }
});

document.addEventListener("click",e=>{

  const btn =
    e.target.closest("button");

  if(!btn) return;

  const action =
    btn.dataset.action;

  if(!action) return;

  if(action === "add-draft-stop"){
    addDraftStop(
      Number(btn.dataset.slot || 0),
      Number(btn.dataset.row || 0)
    );
    return;
  }

  if(action === "remove-draft-stop"){
    removeDraftStop(btn.dataset.id || "");
    return;
  }

  if(action === "confirm-new-stop"){
    confirmNewStop(btn.dataset.id || "");
    return;
  }

  if(action === "remove-confirmed-new-stop"){
    removeConfirmedNewStop(btn.dataset.id || "");
    return;
  }

  if(action === "edit-existing"){
    startExistingEdit(Number(btn.dataset.index || 0));
    return;
  }

  if(action === "confirm-existing-edit"){
    confirmExistingEdit(Number(btn.dataset.index || 0));
    return;
  }

  if(action === "cancel-existing-edit"){
    cancelExistingEdit(Number(btn.dataset.index || 0));
    return;
  }

  if(action === "remove-existing-stop"){
    removeExistingStop(Number(btn.dataset.index || 0));
    return;
  }

  if(action === "edit-dropoff"){
    startDropoffEdit();
    return;
  }

  if(action === "confirm-dropoff-edit"){
    confirmDropoffEdit();
    return;
  }

  if(action === "cancel-dropoff-edit"){
    cancelDropoffEdit();
    return;
  }
});

/* ================= INIT ================= */

async function init(){

  try{

    showLoading();
    hideAlert();
    hideOldControls();

    await loadSystemDesign();

    currentTrip =
      await fetchTripById();

    currentTrip =
      await applyAddStopContext(currentTrip);

    if(isSharedTrip(currentTrip)){
      throw new Error("Add Stop is not available for shared trips");
    }

    if(tripIsClosed(currentTrip)){
      throw new Error("This trip is closed and cannot be modified");
    }

    fillPage(currentTrip);

    showForm();

  }catch(err){

    console.error(err);

    showAlert(
      "error",
      err.message || "Failed to load page"
    );

    if(loadingBox){
      loadingBox.innerHTML = `
        <div style="font-weight:900;color:#991b1b;">
          ${esc(err.message || "Failed to load page")}
        </div>
      `;
    }
  }
}

init();

})();