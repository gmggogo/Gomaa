const express = require("express");
const jwt = require("jsonwebtoken");

const router = express.Router();

const User = require("../models/User");
const SystemDesign = require("../models/SystemDesign");
const DispatchAssignment = require("../models/DispatchAssignment");

const {
  PayrollProfile,
  PayrollPeriodSettings,
  PayrollStaffSchedule,
  PayrollAttendance,
  PayrollPeriodHistory
} = require("../models/Payroll");

const JWT_SECRET =
  process.env.JWT_SECRET ||
  "dev_secret";

/* =========================================================
   PAYROLL ENGINE

   POLICY:
   - Tenant-scoped.
   - SUPER_ADMIN controls one company-wide pay period.
   - No Paid / Unpaid.
   - No Mark Paid.
   - Current period rolls automatically.
   - Time comes from SERVER + tenant timezone stored in SystemDesign.
   - Driver hours remain automatic from trips.
   - Closed periods are snapshotted for future Summary.
   - Staff hours come ONLY from eligible daily Sign In.
   - Staff Sign In credits scheduled hours; no Sign Out.
========================================================= */


/* =========================
   AUTH
========================= */

function readBearerToken(req){

  const header =
    String(
      req.headers?.authorization ||
      ""
    ).trim();

  if(
    !header
      .toLowerCase()
      .startsWith("bearer ")
  ){
    return "";
  }

  return header
    .slice(7)
    .trim();
}

function normalizedRole(value){

  return String(value || "")
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g,"_");
}

function requirePayrollAuth(
  req,
  res,
  next
){

  const token =
    readBearerToken(req);

  if(!token){

    return res
      .status(401)
      .json({
        success:false,
        message:"Access Denied"
      });
  }

  try{

    const verified =
      jwt.verify(
        token,
        JWT_SECRET
      );

    req.authUser = {
      id:
        String(
          verified.id ||
          ""
        ),

      role:
        String(
          verified.role ||
          ""
        ),

      tenantId:
        String(
          verified.tenantId ||
          ""
        )
    };

    if(!req.authUser.tenantId){

      return res
        .status(403)
        .json({
          success:false,
          message:"Tenant Required"
        });
    }

    next();

  }catch(err){

    return res
      .status(401)
      .json({
        success:false,
        message:"Invalid Token"
      });
  }
}

function requireSuperAdmin(
  req,
  res,
  next
){

  if(
    normalizedRole(
      req.authUser?.role
    ) !== "SUPER_ADMIN"
  ){

    return res
      .status(403)
      .json({
        success:false,
        message:"Super Admin only"
      });
  }

  next();
}


/* =========================
   BASIC HELPERS
========================= */

function clean(value){
  return String(value ?? "").trim();
}

function money(value){
  return Number(
    Number(value || 0)
      .toFixed(2)
  );
}

function hours(value){
  return Number(
    Number(value || 0)
      .toFixed(4)
  );
}

function validDateKey(value){

  return /^\d{4}-\d{2}-\d{2}$/
    .test(
      clean(value)
    );
}

/*
  Calendar math intentionally uses UTC.
  These are DATE KEYS, not local timestamps.
  This prevents Render/server local timezone from shifting the day.
*/

function keyToUtc(value){

  if(!validDateKey(value)){
    return null;
  }

  const [
    y,
    m,
    d
  ] =
    value
      .split("-")
      .map(Number);

  return new Date(
    Date.UTC(
      y,
      m - 1,
      d
    )
  );
}

function utcToKey(date){

  return [
    date.getUTCFullYear(),
    String(
      date.getUTCMonth() + 1
    ).padStart(2,"0"),
    String(
      date.getUTCDate()
    ).padStart(2,"0")
  ].join("-");
}

function addDaysKey(
  key,
  days
){

  const date =
    keyToUtc(key);

  if(!date){
    return "";
  }

  date.setUTCDate(
    date.getUTCDate() +
    Number(days || 0)
  );

  return utcToKey(date);
}

function diffDays(
  from,
  to
){

  const a =
    keyToUtc(from);

  const b =
    keyToUtc(to);

  if(!a || !b){
    return 0;
  }

  return Math.round(
    (
      b.getTime() -
      a.getTime()
    ) /
    86400000
  );
}

function inclusiveDays(
  from,
  to
){

  return (
    diffDays(
      from,
      to
    ) + 1
  );
}



function rollingMonthStartKey(
  todayKey,
  monthCount
){

  const date =
    keyToUtc(todayKey);

  if(!date){
    return "";
  }

  const months =
    Math.max(
      1,
      Number(monthCount || 1)
    );

  date.setUTCDate(1);

  date.setUTCMonth(
    date.getUTCMonth() -
    (months - 1)
  );

  return utcToKey(date);
}

/* =========================
   TENANT GLOBAL TIME ENGINE

   Source:
   SystemDesign for THIS tenant.

   The real current instant is generated by the server:
   new Date()

   The tenant timezone decides the calendar date.
========================= */

async function tenantTimezone(
  tenantId
){

  const design =
    await SystemDesign
      .findOne({
        tenantId
      })
      .select(
        "timezone"
      )
      .lean();

  const timezone =
    clean(
      design?.timezone
    ) ||
    "America/Phoenix";

  /*
    Validate IANA timezone.
  */
  try{

    new Intl.DateTimeFormat(
      "en-US",
      {
        timeZone:timezone
      }
    ).format(
      new Date()
    );

    return timezone;

  }catch(err){

    return "America/Phoenix";
  }
}

function dateKeyInTimezone(
  date,
  timezone
){

  const parts =
    new Intl.DateTimeFormat(
      "en-US",
      {
        timeZone:timezone,
        year:"numeric",
        month:"2-digit",
        day:"2-digit"
      }
    )
    .formatToParts(date);

  const map = {};

  for(const part of parts){
    map[part.type] =
      part.value;
  }

  return (
    `${map.year}-` +
    `${map.month}-` +
    `${map.day}`
  );
}

function serverTodayKey(
  timezone
){

  /*
    IMPORTANT:
    This begins with the SERVER'S real current instant.
    Device time is never used.
  */
  return dateKeyInTimezone(
    new Date(),
    timezone
  );
}



async function enforceHistoryRetention(
  tenantId,
  todayKey
){

  const cutoff =
    rollingMonthStartKey(
      todayKey,
      24
    );

  if(!cutoff){
    return;
  }

  await PayrollPeriodHistory
    .deleteMany({
      tenantId,
      periodEnd:{
        $lt:cutoff
      }
    });
}

/* =========================
   PAY PERIOD ENGINE
========================= */

async function getPeriodSettings(
  tenantId,
  timezone
){

  let settings =
    await PayrollPeriodSettings
      .findOne({
        tenantId
      });

  if(settings){
    return settings;
  }

  /*
    Safe initial default:
    current Sunday -> Saturday.
    Super Admin can change it once from the Payroll page.
  */

  const today =
    serverTodayKey(
      timezone
    );

  const date =
    keyToUtc(today);

  const start =
    addDaysKey(
      today,
      -date.getUTCDay()
    );

  settings =
    await PayrollPeriodSettings
      .create({
        tenantId,
        anchorStart:start,
        periodLengthDays:7,
        archiveCursorStart:start
      });

  return settings;
}

function resolvePeriod(
  settings,
  dateKey
){

  const anchor =
    clean(
      settings.anchorStart
    );

  const length =
    Math.max(
      1,
      Number(
        settings.periodLengthDays ||
        7
      )
    );

  const dayOffset =
    diffDays(
      anchor,
      dateKey
    );

  const periodIndex =
    Math.floor(
      dayOffset /
      length
    );

  const start =
    addDaysKey(
      anchor,
      periodIndex * length
    );

  const end =
    addDaysKey(
      start,
      length - 1
    );

  return {
    start,
    end,
    lengthDays:length,
    periodIndex
  };
}

async function getCurrentPeriod(
  tenantId
){

  const timezone =
    await tenantTimezone(
      tenantId
    );

  const settings =
    await getPeriodSettings(
      tenantId,
      timezone
    );

  const today =
    serverTodayKey(
      timezone
    );

  return {
    timezone,
    today,
    settings,
    period:
      resolvePeriod(
        settings,
        today
      )
  };
}


/* =========================
   TRIP STATUS HELPERS
========================= */

function normalizeStatus(value){

  return clean(value)
    .toUpperCase()
    .replace(/[\s_-]+/g,"");
}

function tripStatus(trip){

  return (
    normalizeStatus(
      trip?.status
    ) ||
    normalizeStatus(
      trip?.dispatchStatus
    )
  );
}

function isCancelled(trip){

  const s =
    tripStatus(trip);

  return (
    s === "CANCELLED" ||
    s === "CANCELED"
  );
}

function isNotCompleted(trip){

  return (
    tripStatus(trip) ===
    "NOTCOMPLETED"
  );
}

function isCompleted(trip){

  return (
    tripStatus(trip) ===
    "COMPLETED"
  );
}

function isNoShow(trip){

  return (
    tripStatus(trip) ===
    "NOSHOW"
  );
}

function isActiveTrip(trip){

  return [
    "ONTRIP",
    "INPROGRESS",
    "ARRIVED",
    "ACCEPTED",
    "SENT",
    "ASSIGNED",
    "SCHEDULED",
    "CONFIRMED",
    "AUTOASSIGNED"
  ].includes(
    tripStatus(trip)
  );
}

function scheduledDate(trip){

  const d =
    clean(
      trip?.tripDate ||
      trip?.date
    );

  const t =
    clean(
      trip?.tripTime ||
      trip?.time ||
      "00:00"
    );

  if(!d){
    return null;
  }

  const date =
    new Date(
      `${d}T${t}`
    );

  return Number.isNaN(
    date.getTime()
  )
    ? null
    : date;
}

function finalMoment(trip){

  const candidates = [
    trip?.historyAt,
    trip?.finalizedAt,
    trip?.finalStatusConfirmedAt,
    trip?.sharedFinalConfirmedAt,
    trip?.dispatchFinalConfirmedAt,
    trip?.cancelDateTime,
    trip?.assignmentCompletedAt
  ];

  for(
    const value
    of candidates
  ){

    if(!value){
      continue;
    }

    const date =
      new Date(value);

    if(
      !Number.isNaN(
        date.getTime()
      )
    ){
      return date;
    }
  }

  return null;
}


/* =========================
   DRIVER HOURS ENGINE

   Same business rule:
   first scheduled pickup -> last final time.
   Time between trips counts.
========================= */

function buildDriverDay(
  dayTrips,
  dayKey,
  todayKey
){

  const now =
    new Date();

  const workable =
    dayTrips
      .map(
        trip=>({
          trip,
          scheduled:
            scheduledDate(
              trip
            )
        })
      )
      .filter(
        item=>
          item.scheduled &&
          !isCancelled(
            item.trip
          ) &&
          !isNotCompleted(
            item.trip
          )
      )
      .sort(
        (a,b)=>
          a.scheduled -
          b.scheduled
      );

  if(!workable.length){
    return null;
  }

  const start =
    new Date(
      workable[0]
        .scheduled
    );

  if(
    dayKey ===
      todayKey &&
    now < start
  ){
    return null;
  }

  const finalTimes =
    workable
      .map(
        item=>{

          if(
            isCompleted(
              item.trip
            ) ||
            isNoShow(
              item.trip
            )
          ){
            return finalMoment(
              item.trip
            );
          }

          return null;
        }
      )
      .filter(Boolean);

  const hasOpenWork =
    workable.some(
      item=>
        isActiveTrip(
          item.trip
        ) &&
        item.scheduled <=
          now
    );

  let end = null;
  let running = false;

  if(
    dayKey ===
      todayKey &&
    hasOpenWork
  ){

    end = now;
    running = true;

  }else if(
    finalTimes.length
  ){

    end =
      new Date(
        Math.max(
          ...finalTimes
            .map(
              date=>
                date.getTime()
            )
        )
      );
  }

  if(
    !end ||
    end < start
  ){
    return null;
  }

  return {
    date:dayKey,
    start,
    end,
    hours:
      hours(
        (
          end -
          start
        ) /
        3600000
      ),

    tripCount:
      workable.length,

    running
  };
}

async function driverDailyHours(
  tenantId,
  driverId,
  from,
  to,
  timezone
){

  const Trip =
    global.Trip;

  if(!Trip){

    throw new Error(
      "Trip model is not ready"
    );
  }

  /*
    Read assignment status too, just like the
    existing driver trip pipeline.
  */

  const assignments =
    await DispatchAssignment
      .find({
        driverId:
          String(
            driverId
          )
      })
      .select(
        "tripId driverId dispatchStatus sentAt acceptedAt startedAt completedAt"
      )
      .lean();

  const tripIds =
    assignments
      .map(
        row=>
          row.tripId
      )
      .filter(Boolean);

  if(!tripIds.length){
    return [];
  }

  const assignmentMap =
    new Map();

  assignments
    .forEach(
      row=>{

        assignmentMap.set(
          String(row.tripId),
          row
        );
      }
    );

  const trips =
    await Trip
      .find({
        _id:{
          $in:tripIds
        },

        tenantId,

        tripDate:{
          $gte:from,
          $lte:to
        },

        disabled:{
          $ne:true
        }
      })
      .select(
        "tripDate tripTime status historyAt finalizedAt finalStatusConfirmedAt sharedFinalConfirmedAt dispatchFinalConfirmedAt cancelDateTime"
      )
      .lean();

  const groups = {};

  trips.forEach(
    trip=>{

      const assignment =
        assignmentMap.get(
          String(
            trip._id
          )
        ) ||
        {};

      const merged = {
        ...trip,

        dispatchStatus:
          assignment.dispatchStatus ||
          "",

        assignmentCompletedAt:
          assignment.completedAt ||
          null
      };

      const key =
        clean(
          merged.tripDate
        );

      if(!key){
        return;
      }

      if(!groups[key]){
        groups[key] = [];
      }

      groups[key]
        .push(
          merged
        );
    }
  );

  const todayKey =
    serverTodayKey(
      timezone
    );

  return Object
    .keys(groups)
    .sort()
    .map(
      key=>
        buildDriverDay(
          groups[key],
          key,
          todayKey
        )
    )
    .filter(Boolean);
}

async function staffAttendanceDailyHours(
  tenantId,
  personType,
  personId,
  from,
  to
){

  const rows =
    await PayrollAttendance
      .find({
        tenantId,
        personType,
        personId:
          String(
            personId
          ),

        workDate:{
          $gte:from,
          $lte:to
        }
      })
      .sort({
        workDate:1
      })
      .lean();

  return rows
    .map(
      row=>({
        date:
          row.workDate,

        hours:
          hours(
            row.creditedHours
          ),

        tripCount:0,

        running:false,

        signedAt:
          row.signedAt ||
          null
      })
    );
}


/* =========================
   STAFF SCHEDULE HELPERS
========================= */

const STAFF_TYPES = [
  "dispatcher",
  "admin",
  "super_admin"
];

const DAY_KEYS = [
  "sun",
  "mon",
  "tue",
  "wed",
  "thu",
  "fri",
  "sat"
];

function personTypeFromRole(
  role
){

  const r =
    normalizedRole(
      role
    );

  if(r === "DISPATCHER"){
    return "dispatcher";
  }

  if(r === "ADMIN"){
    return "admin";
  }

  if(r === "SUPER_ADMIN"){
    return "super_admin";
  }

  return "";
}

function emptyScheduleDays(){

  return {
    sun:{
      enabled:false,
      hours:0
    },

    mon:{
      enabled:false,
      hours:0
    },

    tue:{
      enabled:false,
      hours:0
    },

    wed:{
      enabled:false,
      hours:0
    },

    thu:{
      enabled:false,
      hours:0
    },

    fri:{
      enabled:false,
      hours:0
    },

    sat:{
      enabled:false,
      hours:0
    }
  };
}

function normalizeScheduleDays(
  input
){

  const days =
    emptyScheduleDays();

  for(
    const key
    of DAY_KEYS
  ){

    const source =
      input?.[key] ||
      {};

    const enabled =
      source.enabled === true;

    const dayHours =
      Math.max(
        0,
        Math.min(
          24,
          Number(
            source.hours ||
            0
          )
        )
      );

    days[key] = {
      enabled,
      hours:
        enabled
          ? dayHours
          : 0
    };
  }

  return days;
}

function weekdayKeyFromDateKey(
  dateKey
){

  const date =
    keyToUtc(
      dateKey
    );

  if(!date){
    return "";
  }

  return DAY_KEYS[
    date.getUTCDay()
  ] || "";
}

async function getStaffSchedule(
  tenantId,
  personType,
  personId
){

  let schedule =
    await PayrollStaffSchedule
      .findOne({
        tenantId,
        personType,
        personId:
          String(
            personId
          )
      });

  if(!schedule){

    schedule =
      await PayrollStaffSchedule
        .create({
          tenantId,
          personType,
          personId:
            String(
              personId
            ),

          payrollEnabled:false,

          days:
            emptyScheduleDays()
        });
  }

  return schedule;
}

function scheduleForClient(
  schedule
){

  const raw =
    schedule?.toObject
      ? schedule.toObject()
      : schedule || {};

  return {
    payrollEnabled:
      raw.payrollEnabled === true,

    days:
      normalizeScheduleDays(
        raw.days ||
        {}
      )
  };
}


/* =========================
   PAY CALCULATION

   Overtime resets every Sunday.
========================= */

function weekStartKey(
  dateKey
){

  const date =
    keyToUtc(
      dateKey
    );

  if(!date){
    return "";
  }

  return addDaysKey(
    dateKey,
    -date.getUTCDay()
  );
}

function splitRegularAndOvertime(
  dailyRows,
  overtimeAfterHours
){

  const threshold =
    Math.max(
      0,
      Number(
        overtimeAfterHours ??
        40
      )
    );

  const weeks =
    new Map();

  dailyRows
    .forEach(
      row=>{

        const week =
          weekStartKey(
            row.date
          );

        if(
          !weeks.has(
            week
          )
        ){
          weeks.set(
            week,
            []
          );
        }

        weeks
          .get(week)
          .push(row);
      }
    );

  let regularHours = 0;
  let overtimeHours = 0;

  for(
    const rows
    of weeks.values()
  ){

    const weekHours =
      rows.reduce(
        (sum,row)=>
          sum +
          Number(
            row.hours ||
            0
          ),
        0
      );

    regularHours +=
      Math.min(
        weekHours,
        threshold
      );

    overtimeHours +=
      Math.max(
        0,
        weekHours -
        threshold
      );
  }

  return {
    regularHours:
      hours(
        regularHours
      ),

    overtimeHours:
      hours(
        overtimeHours
      ),

    totalHours:
      hours(
        regularHours +
        overtimeHours
      )
  };
}

async function getProfile(
  tenantId,
  personType,
  personId
){

  let profile =
    await PayrollProfile
      .findOne({
        tenantId,
        personType,
        personId:
          String(
            personId
          )
      });

  if(!profile){

    profile =
      await PayrollProfile
        .create({
          tenantId,
          personType,
          personId:
            String(
              personId
            ),

          hourlyRate:0,
          overtimeRate:0,
          overtimeAfterHours:40
        });
  }

  return profile;
}

async function calculatePerson(
  tenantId,
  personType,
  person,
  from,
  to,
  timezone
){

  const personId =
    String(
      person._id
    );

  const profile =
    await getProfile(
      tenantId,
      personType,
      personId
    );

  const staffSchedule =
    STAFF_TYPES.includes(
      personType
    )
      ? await getStaffSchedule(
          tenantId,
          personType,
          personId
        )
      : null;

  const dailyHours =
    personType ===
      "driver"

      ? await driverDailyHours(
          tenantId,
          personId,
          from,
          to,
          timezone
        )

      : await staffAttendanceDailyHours(
          tenantId,
          personType,
          personId,
          from,
          to
        );

  const split =
    splitRegularAndOvertime(
      dailyHours,
      profile.overtimeAfterHours
    );

  const tripCount =
    personType === "driver"
      ? dailyHours.reduce(
          (sum,row)=>
            sum +
            Number(
              row.tripCount ||
              0
            ),
          0
        )
      : 0;

  const hourlyRate =
    money(
      profile.hourlyRate
    );

  const overtimeRate =
    money(
      profile.overtimeRate
    );

  const regularPay =
    money(
      split.regularHours *
      hourlyRate
    );

  const overtimePay =
    money(
      split.overtimeHours *
      overtimeRate
    );

  const totalDue =
    money(
      regularPay +
      overtimePay
    );

  return {
    _id:personId,

    name:
      person.name ||
      person.username ||
      "",

    username:
      person.username ||
      "",

    email:
      person.email ||
      "",

    phone:
      person.phone ||
      "",

    jobTitle:
      person.jobTitle ||
      "",

    employeeNumber:
      person.employeeNumber ||
      "",

    active:
      person.active !== false &&
      person.enabled !== false,

    personType,

    hourlyRate,
    overtimeRate,

    overtimeAfterHours:
      Number(
        profile
          .overtimeAfterHours ??
        40
      ),

    regularHours:
      split.regularHours,

    overtimeHours:
      split.overtimeHours,

    totalHours:
      split.totalHours,

    tripCount,

    regularPay,
    overtimePay,
    totalDue,

    dailyHours,

    staffSchedule:
      staffSchedule
        ? scheduleForClient(
            staffSchedule
          )
        : null
  };
}


/* =========================
   PEOPLE SOURCES
========================= */

async function loadPeople(
  tenantId,
  personType
){

  const roleMap = {
    driver:[
      "driver"
    ],

    dispatcher:[
      "dispatcher"
    ],

    admin:[
      "admin"
    ],

    super_admin:[
      "SUPER_ADMIN"
    ]
  };

  const roles =
    roleMap[
      personType
    ];

  if(!roles){
    return [];
  }

  return await User
    .find({
      tenantId,
      role:{
        $in:roles
      }
    })
    .select(
      "_id name username email phone role active enabled"
    )
    .sort({
      name:1
    })
    .lean();
}


/* =========================
   AUTOMATIC HISTORY SNAPSHOT
========================= */

const PERSON_TYPES = [
  "driver",
  "dispatcher",
  "admin",
  "super_admin"
];

async function archiveOnePeriod(
  tenantId,
  from,
  to,
  timezone
){

  for(
    const personType
    of PERSON_TYPES
  ){

    const people =
      await loadPeople(
        tenantId,
        personType
      );

    for(
      const person
      of people
    ){

      const calc =
        await calculatePerson(
          tenantId,
          personType,
          person,
          from,
          to,
          timezone
        );

      await PayrollPeriodHistory
        .findOneAndUpdate(
          {
            tenantId,
            personType,
            personId:
              String(
                person._id
              ),
            periodStart:from,
            periodEnd:to
          },
          {
            $setOnInsert:{
              personName:
                calc.name,

              timezone,

              regularHours:
                calc.regularHours,

              overtimeHours:
                calc.overtimeHours,

              totalHours:
                calc.totalHours,

              tripCount:
                calc.tripCount,

              hourlyRate:
                calc.hourlyRate,

              overtimeRate:
                calc.overtimeRate,

              overtimeAfterHours:
                calc.overtimeAfterHours,

              regularPay:
                calc.regularPay,

              overtimePay:
                calc.overtimePay,

              totalDue:
                calc.totalDue,

              dailyHours:
                calc.dailyHours,

              closedAt:
                new Date()
            }
          },
          {
            upsert:true,
            new:true,
            setDefaultsOnInsert:true
          }
        );
    }
  }
}

async function ensureClosedPeriods(
  tenantId
){

  const info =
    await getCurrentPeriod(
      tenantId
    );

  const {
    timezone,
    settings,
    period
  } = info;

  let cursor =
    clean(
      settings
        .archiveCursorStart
    ) ||
    clean(
      settings
        .anchorStart
    );

  /*
    If configuration was created in the future,
    there is nothing to archive yet.
  */
  if(
    !cursor ||
    cursor >=
      period.start
  ){

    if(
      cursor !==
      period.start
    ){

      settings.archiveCursorStart =
        period.start;

      await settings.save();
    }

    return info;
  }

  let guard = 0;

  while(
    cursor <
      period.start &&
    guard < 60
  ){

    const end =
      addDaysKey(
        cursor,
        Number(
          settings
            .periodLengthDays ||
          7
        ) - 1
      );

    if(
      end >=
      period.start
    ){
      break;
    }

    await archiveOnePeriod(
      tenantId,
      cursor,
      end,
      timezone
    );

    cursor =
      addDaysKey(
        end,
        1
      );

    guard += 1;
  }

  settings.archiveCursorStart =
    period.start;

  await settings.save();


  /*
    ADMIN RETENTION:
    Keep only the rolling last 24 calendar months
    in PayrollPeriodHistory.
    Driver access is separately limited to 6 months.
  */

  const adminCutoff =
    rollingMonthStartKey(
      info.today,
      24
    );

  if(adminCutoff){

    await PayrollPeriodHistory
      .deleteMany({
        tenantId,
        periodEnd:{
          $lt:adminCutoff
        }
      });
  }

  return info;
}


/* =========================
   CURRENT PAY PERIOD
========================= */

router.get(
  "/period",
  requirePayrollAuth,
  async(req,res)=>{

    try{

      const info =
        await ensureClosedPeriods(
          req.authUser.tenantId
        );

      return res.json({
        success:true,

        timezone:
          info.timezone,

        serverToday:
          info.today,

        period:{
          from:
            info.period.start,

          to:
            info.period.end,

          lengthDays:
            info.period.lengthDays
        }
      });

    }catch(err){

      console.log(
        "PAYROLL PERIOD ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Pay period load failed"
        });
    }
  }
);


/* =========================
   SET COMPANY-WIDE PAY PERIOD
   SUPER ADMIN ONLY

   User selects one example period.
   System repeats same duration automatically forever.
========================= */

router.put(
  "/period",
  requirePayrollAuth,
  requireSuperAdmin,
  async(req,res)=>{

    try{

      const from =
        clean(
          req.body?.from
        );

      const to =
        clean(
          req.body?.to
        );

      if(
        !validDateKey(from) ||
        !validDateKey(to) ||
        from > to
      ){

        return res
          .status(400)
          .json({
            message:
              "Invalid pay period"
          });
      }

      const lengthDays =
        inclusiveDays(
          from,
          to
        );

      if(
        lengthDays < 1 ||
        lengthDays > 366
      ){

        return res
          .status(400)
          .json({
            message:
              "Invalid pay period length"
          });
      }

      const settings =
        await PayrollPeriodSettings
          .findOneAndUpdate(
            {
              tenantId:
                req.authUser
                  .tenantId
            },
            {
              $set:{
                anchorStart:
                  from,

                periodLengthDays:
                  lengthDays,

                archiveCursorStart:
                  from,

                updatedBy:
                  req.authUser.id
              }
            },
            {
              upsert:true,
              new:true,
              setDefaultsOnInsert:true
            }
          );

      const timezone =
        await tenantTimezone(
          req.authUser
            .tenantId
        );

      const today =
        serverTodayKey(
          timezone
        );

      const period =
        resolvePeriod(
          settings,
          today
        );

      return res.json({
        success:true,
        timezone,
        serverToday:today,
        period:{
          from:period.start,
          to:period.end,
          lengthDays:
            period.lengthDays
        }
      });

    }catch(err){

      console.log(
        "PAYROLL PERIOD SAVE ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Pay period save failed"
        });
    }
  }
);


/* =========================
   PEOPLE - CURRENT PERIOD ONLY
========================= */

router.get(
  "/people",
  requirePayrollAuth,
  requireSuperAdmin,
  async(req,res)=>{

    try{

      const personType =
        clean(
          req.query.type
        );

      if(
        !PERSON_TYPES
          .includes(
            personType
          )
      ){

        return res
          .status(400)
          .json({
            message:
              "Invalid payroll type"
          });
      }

      const info =
        await ensureClosedPeriods(
          req.authUser.tenantId
        );

      const from =
        info.period.start;

      const to =
        info.period.end;

      const people =
        await loadPeople(
          req.authUser.tenantId,
          personType
        );

      const result = [];

      for(
        const person
        of people
      ){

        result.push(
          await calculatePerson(
            req.authUser
              .tenantId,

            personType,
            person,
            from,
            to,
            info.timezone
          )
        );
      }

      return res.json({
        success:true,
        type:personType,
        timezone:
          info.timezone,
        serverToday:
          info.today,
        from,
        to,
        lengthDays:
          info.period
            .lengthDays,
        people:result
      });

    }catch(err){

      console.log(
        "PAYROLL LIST ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Payroll load failed"
        });
    }
  }
);


/* =========================
   SAVE PAY SETTINGS
========================= */

router.put(
  "/profile/:type/:id",
  requirePayrollAuth,
  requireSuperAdmin,
  async(req,res)=>{

    try{

      /*
        Before changing a rate, close every old period
        using the old rate.
      */
      await ensureClosedPeriods(
        req.authUser.tenantId
      );

      const personType =
        clean(
          req.params.type
        );

      if(
        !PERSON_TYPES
          .includes(
            personType
          )
      ){

        return res
          .status(400)
          .json({
            message:
              "Invalid payroll type"
          });
      }

      const hourlyRate =
        Math.max(
          0,
          Number(
            req.body
              ?.hourlyRate ||
            0
          )
        );

      const overtimeRate =
        Math.max(
          0,
          Number(
            req.body
              ?.overtimeRate ||
            0
          )
        );

      const overtimeAfterHours =
        Math.max(
          0,
          Number(
            req.body
              ?.overtimeAfterHours ??
            40
          )
        );

      const profile =
        await PayrollProfile
          .findOneAndUpdate(
            {
              tenantId:
                req.authUser
                  .tenantId,

              personType,

              personId:
                String(
                  req.params.id
                )
            },
            {
              $set:{
                hourlyRate,
                overtimeRate,
                overtimeAfterHours
              }
            },
            {
              new:true,
              upsert:true,
              setDefaultsOnInsert:true
            }
          );

      return res.json({
        success:true,
        profile
      });

    }catch(err){

      console.log(
        "PAYROLL PROFILE ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Settings save failed"
        });
    }
  }
);


/* =========================
   STAFF SCHEDULE
   SUPER ADMIN ONLY
========================= */

router.put(
  "/staff-schedule/:type/:id",
  requirePayrollAuth,
  requireSuperAdmin,
  async(req,res)=>{

    try{

      const personType =
        clean(
          req.params.type
        );

      if(
        !STAFF_TYPES.includes(
          personType
        )
      ){

        return res
          .status(400)
          .json({
            message:
              "Invalid staff payroll type"
          });
      }

      /*
        Confirm the person belongs to this tenant
        and matches the selected role.
      */
      const roleMap = {
        dispatcher:"dispatcher",
        admin:"admin",
        super_admin:"SUPER_ADMIN"
      };

      const person =
        await User
          .findOne({
            _id:
              req.params.id,

            tenantId:
              req.authUser
                .tenantId,

            role:
              roleMap[
                personType
              ]
          })
          .select(
            "_id name role"
          )
          .lean();

      if(!person){

        return res
          .status(404)
          .json({
            message:
              "Staff member not found"
          });
      }

      /*
        Close old completed periods first.
      */
      await ensureClosedPeriods(
        req.authUser.tenantId
      );

      const days =
        normalizeScheduleDays(
          req.body?.days ||
          {}
        );

      const payrollEnabled =
        req.body
          ?.payrollEnabled === true;

      const hourlyRate =
        Math.max(
          0,
          Number(
            req.body
              ?.hourlyRate ||
            0
          )
        );

      const overtimeRate =
        Math.max(
          0,
          Number(
            req.body
              ?.overtimeRate ||
            0
          )
        );

      const weeklyHours =
        Math.max(
          0,
          Number(
            req.body
              ?.weeklyHours ??
            40
          )
        );

      const schedule =
        await PayrollStaffSchedule
          .findOneAndUpdate(
            {
              tenantId:
                req.authUser
                  .tenantId,

              personType,

              personId:
                String(
                  req.params.id
                )
            },
            {
              $set:{
                payrollEnabled,
                days,
                updatedBy:
                  req.authUser.id
              }
            },
            {
              upsert:true,
              new:true,
              setDefaultsOnInsert:true
            }
          );

      const profile =
        await PayrollProfile
          .findOneAndUpdate(
            {
              tenantId:
                req.authUser
                  .tenantId,

              personType,

              personId:
                String(
                  req.params.id
                )
            },
            {
              $set:{
                hourlyRate,
                overtimeRate,

                /*
                  Weekly Hours is the regular-hours
                  threshold before overtime.
                */
                overtimeAfterHours:
                  weeklyHours,

                enabled:true
              }
            },
            {
              upsert:true,
              new:true,
              setDefaultsOnInsert:true
            }
          );

      return res.json({
        success:true,

        schedule:
          scheduleForClient(
            schedule
          ),

        profile:{
          hourlyRate:
            profile.hourlyRate,

          overtimeRate:
            profile.overtimeRate,

          weeklyHours:
            profile
              .overtimeAfterHours
        }
      });

    }catch(err){

      console.log(
        "STAFF PAYROLL SCHEDULE SAVE ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Staff schedule save failed"
        });
    }
  }
);


/* =========================
   STAFF SIGN IN STATUS

   This is called by the header BEFORE
   showing the SIGN IN button.
========================= */

router.get(
  "/staff-signin/status",
  requirePayrollAuth,
  async(req,res)=>{

    try{

      const personType =
        personTypeFromRole(
          req.authUser.role
        );

      if(
        !STAFF_TYPES.includes(
          personType
        )
      ){

        return res.json({
          success:true,
          supported:false,
          showSignIn:false,
          signed:false
        });
      }

      const info =
        await getCurrentPeriod(
          req.authUser.tenantId
        );

      const today =
        info.today;

      const dayKey =
        weekdayKeyFromDateKey(
          today
        );

      const schedule =
        await getStaffSchedule(
          req.authUser.tenantId,
          personType,
          req.authUser.id
        );

      const clientSchedule =
        scheduleForClient(
          schedule
        );

      const todayRule =
        clientSchedule
          .days
          ?.[dayKey] ||
        {
          enabled:false,
          hours:0
        };

      const eligible =
        clientSchedule
          .payrollEnabled === true &&
        todayRule
          .enabled === true &&
        Number(
          todayRule.hours ||
          0
        ) > 0;

      if(!eligible){

        return res.json({
          success:true,
          supported:true,
          showSignIn:false,
          signed:false,
          eligible:false,
          today,
          dayKey,
          timezone:
            info.timezone
        });
      }

      const attendance =
        await PayrollAttendance
          .findOne({
            tenantId:
              req.authUser
                .tenantId,

            personType,

            personId:
              String(
                req.authUser.id
              ),

            workDate:
              today
          })
          .lean();

      return res.json({
        success:true,
        supported:true,
        eligible:true,

        /*
          Header only shows SIGN IN if the person
          is scheduled today and has not signed yet.
        */
        showSignIn:
          !attendance,

        signed:
          !!attendance,

        today,
        dayKey,

        creditedHours:
          attendance
            ? Number(
                attendance
                  .creditedHours ||
                0
              )
            : Number(
                todayRule.hours ||
                0
              ),

        timezone:
          info.timezone
      });

    }catch(err){

      console.log(
        "STAFF SIGNIN STATUS ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Sign In status failed"
        });
    }
  }
);


/* =========================
   STAFF SIGN IN

   No Sign Out.
   Successful Sign In credits the scheduled
   hours for today as a snapshot.
========================= */

router.post(
  "/staff-signin",
  requirePayrollAuth,
  async(req,res)=>{

    try{

      const personType =
        personTypeFromRole(
          req.authUser.role
        );

      if(
        !STAFF_TYPES.includes(
          personType
        )
      ){

        return res
          .status(403)
          .json({
            message:
              "Sign In is not available for this role"
          });
      }

      const info =
        await getCurrentPeriod(
          req.authUser.tenantId
        );

      const today =
        info.today;

      const dayKey =
        weekdayKeyFromDateKey(
          today
        );

      const schedule =
        await getStaffSchedule(
          req.authUser.tenantId,
          personType,
          req.authUser.id
        );

      const clientSchedule =
        scheduleForClient(
          schedule
        );

      const todayRule =
        clientSchedule
          .days
          ?.[dayKey] ||
        {
          enabled:false,
          hours:0
        };

      if(
        clientSchedule
          .payrollEnabled !== true
      ){

        return res
          .status(403)
          .json({
            message:
              "Payroll Sign In is disabled for your account"
          });
      }

      if(
        todayRule
          .enabled !== true ||
        Number(
          todayRule.hours ||
          0
        ) <= 0
      ){

        return res
          .status(403)
          .json({
            message:
              "Today is not a scheduled work day"
          });
      }

      /*
        Idempotent: repeated taps cannot create
        duplicate credited days.
      */
      const attendance =
        await PayrollAttendance
          .findOneAndUpdate(
            {
              tenantId:
                req.authUser
                  .tenantId,

              personType,

              personId:
                String(
                  req.authUser.id
                ),

              workDate:
                today
            },
            {
              $setOnInsert:{
                dayKey,

                creditedHours:
                  Number(
                    todayRule.hours
                  ),

                signedAt:
                  new Date(),

                timezone:
                  info.timezone
              }
            },
            {
              upsert:true,
              new:true,
              setDefaultsOnInsert:true
            }
          );

      return res.json({
        success:true,
        signed:true,
        today,
        dayKey,

        creditedHours:
          Number(
            attendance
              .creditedHours ||
            todayRule.hours ||
            0
          ),

        timezone:
          info.timezone
      });

    }catch(err){

      /*
        Unique index race safety.
      */
      if(
        Number(
          err?.code
        ) === 11000
      ){

        return res.json({
          success:true,
          signed:true,
          message:
            "Already signed in today"
        });
      }

      console.log(
        "STAFF SIGNIN ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Sign In failed"
        });
    }
  }
);


/* =========================
   DRIVER CURRENT EARNINGS
   NO DATE INPUT FROM DEVICE.
   SERVER RESOLVES CURRENT PERIOD.
========================= */

router.get(
  "/me",
  requirePayrollAuth,
  async(req,res)=>{

    try{

      if(
        normalizedRole(
          req.authUser.role
        ) !== "DRIVER"
      ){

        return res
          .status(403)
          .json({
            message:
              "Driver only"
          });
      }

      const info =
        await ensureClosedPeriods(
          req.authUser.tenantId
        );

      const driver =
        await User
          .findOne({
            _id:
              req.authUser.id,

            tenantId:
              req.authUser
                .tenantId,

            role:"driver"
          })
          .select(
            "_id name username email phone role active enabled"
          )
          .lean();

      if(!driver){

        return res
          .status(404)
          .json({
            message:
              "Driver not found"
          });
      }

      const result =
        await calculatePerson(
          req.authUser.tenantId,
          "driver",
          driver,
          info.period.start,
          info.period.end,
          info.timezone
        );

      return res.json({
        success:true,

        timezone:
          info.timezone,

        serverToday:
          info.today,

        from:
          info.period.start,

        to:
          info.period.end,

        lengthDays:
          info.period
            .lengthDays,

        earnings:
          result
      });

    }catch(err){

      console.log(
        "DRIVER EARNINGS ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Earnings load failed"
        });
    }
  }
);


/* =========================
   CLOSED PERIOD HISTORY
   FOR FUTURE SUMMARY PAGE
========================= */

router.get(
  "/history",
  requirePayrollAuth,
  async(req,res)=>{

    try{

      const role =
        normalizedRole(
          req.authUser.role
        );

      const info =
        await ensureClosedPeriods(
          req.authUser.tenantId
        );

      await enforceHistoryRetention(
        req.authUser.tenantId,
        info.today
      );

      const filter = {
        tenantId:
          req.authUser
            .tenantId
      };

      let retentionMonths = 24;

      if(
        role === "DRIVER"
      ){

        retentionMonths = 6;

        filter.personType =
          "driver";

        filter.personId =
          String(
            req.authUser.id
          );

      }else if(
        role === "SUPER_ADMIN"
      ){

        const type =
          clean(
            req.query.type
          );

        if(
          type &&
          PERSON_TYPES
            .includes(type)
        ){
          filter.personType =
            type;
        }

        const personId =
          clean(
            req.query.personId
          );

        if(personId){
          filter.personId =
            personId;
        }

      }else{

        return res
          .status(403)
          .json({
            message:
              "Access denied"
          });
      }

      const cutoff =
        rollingMonthStartKey(
          info.today,
          retentionMonths
        );

      if(cutoff){

        filter.periodEnd = {
          $gte:cutoff
        };
      }

      const rows =
        await PayrollPeriodHistory
          .find(filter)
          .sort({
            periodStart:-1,
            personName:1
          })
          .limit(1000)
          .lean();

      return res.json({
        success:true,

        timezone:
          info.timezone,

        serverToday:
          info.today,

        retentionMonths,

        history:rows
      });

    }catch(err){

      console.log(
        "PAYROLL HISTORY ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Payroll history load failed"
        });
    }
  }
);


/* =========================
   ADMIN PAYROLL SUMMARY
   PER PERSON
   LAST 24 ROLLING MONTHS

   Supported groups:
   driver | dispatcher | admin | super_admin | employee

   Each person gets their own summary:
   - name
   - from / to
   - total hours
   - trips (drivers only)
   - total earnings
========================= */

router.get(
  "/admin-summary",
  requirePayrollAuth,
  requireSuperAdmin,
  async(req,res)=>{

    try{

      const info =
        await ensureClosedPeriods(
          req.authUser.tenantId
        );

      await enforceHistoryRetention(
        req.authUser.tenantId,
        info.today
      );

      const personType =
        clean(
          req.query.type
        );

      const validTypes = [
        "driver",
        "dispatcher",
        "admin",
        "super_admin"
      ];

      if(
        !validTypes.includes(
          personType
        )
      ){

        return res
          .status(400)
          .json({
            message:
              "Select a valid payroll group"
          });
      }

      const cutoff =
        rollingMonthStartKey(
          info.today,
          24
        );

      const match = {
        tenantId:
          req.authUser.tenantId,
        personType
      };

      if(cutoff){

        match.periodEnd = {
          $gte:cutoff
        };
      }

      const historyRows =
        await PayrollPeriodHistory
          .find(match)
          .sort({
            personName:1,
            periodStart:-1
          })
          .lean();

      const currentPeople =
        await loadPeople(
          req.authUser.tenantId,
          personType
        );

      const peopleMap =
        new Map();

      for(const person of currentPeople){

        const id =
          String(
            person._id
          );

        peopleMap.set(
          id,
          {
            personId:id,

            name:
              person.name ||
              person.username ||
              "Unknown",

            jobTitle:
              person.jobTitle ||
              "",

            employeeNumber:
              person.employeeNumber ||
              "",

            periods:[]
          }
        );
      }

      for(const row of historyRows){

        const id =
          String(
            row.personId
          );

        if(!peopleMap.has(id)){

          peopleMap.set(
            id,
            {
              personId:id,

              name:
                row.personName ||
                "Unknown",

              jobTitle:"",
              employeeNumber:"",
              periods:[]
            }
          );
        }

        peopleMap
          .get(id)
          .periods
          .push({
            from:
              row.periodStart,

            to:
              row.periodEnd,

            totalHours:
              hours(
                row.totalHours
              ),

            totalTrips:
              personType === "driver"
                ? Number(
                    row.tripCount ||
                    0
                  )
                : 0,

            totalEarnings:
              money(
                row.totalDue
              )
          });
      }

      const people =
        Array
          .from(
            peopleMap.values()
          )
          .sort(
            (a,b)=>
              String(
                a.name
              ).localeCompare(
                String(
                  b.name
                )
              )
          );

      const totals =
        historyRows.reduce(
          (acc,row)=>{

            acc.totalHours +=
              Number(
                row.totalHours ||
                0
              );

            acc.totalTrips +=
              personType === "driver"
                ? Number(
                    row.tripCount ||
                    0
                  )
                : 0;

            acc.totalEarnings +=
              Number(
                row.totalDue ||
                0
              );

            return acc;
          },
          {
            totalHours:0,
            totalTrips:0,
            totalEarnings:0
          }
        );

      return res.json({
        success:true,

        type:
          personType,

        timezone:
          info.timezone,

        serverToday:
          info.today,

        retentionMonths:24,

        totals:{
          people:
            people.length,

          totalHours:
            hours(
              totals.totalHours
            ),

          totalTrips:
            totals.totalTrips,

          totalEarnings:
            money(
              totals.totalEarnings
            )
        },

        people
      });

    }catch(err){

      console.log(
        "ADMIN PAYROLL SUMMARY ERROR:",
        err
      );

      return res
        .status(500)
        .json({
          message:
            "Payroll summary load failed"
        });
    }
  }
);


module.exports = router;